--Create a Database named EmployeesManagementDB
Create Database EmployeesManagementDB

use EmployeesManagementDB

--Tbl_Employees 
--: EmployeeID , EmployeeName , EmployeeCity ,EmployeeSalary EmployeeDOB , EmployeeDOJ , 
--EmployeeMobileNo , EmployeeEmailID , EmployeePassword  , EmployeeDept)

create table tbl_Employees
(
EmployeeID int identity(1000,1) primary key,
EmployeeName varchar(100) not null,
EmployeeCity varchar(100) not null,
EmployeeSalary int not null,
EmployeeDOB datetime not null,
EmployeeDOJ datetime not null,
EmployeeMobileNo varchar(15) not null unique,
EmployeeEmailID varchar(100) not null unique,
EmployeePassword varchar(100) not null unique,
EmployeeDept varchar(100) not null
)

select * from tbl_Employees

insert tbl_Employees values('Mounika','BGL',30000,'11/30/1996','12/12/2018','9948498834','mouni@gmail.com','pass@123','HR')
insert tbl_Employees values('Bhagya','Chennai',20000,'06/14/1995','01/23/2015','9948492234','bhagya@gmail.com','pass@345','Manager')
insert tbl_Employees values('Anil','BGL',35000,'09/28/1996','02/12/2014','9948491134','anil@gmail.com','pass@567','CEO')
insert tbl_Employees values('Surekha','Chennai',40000,'01/10/1995','12/25/2018','9948496634','surekha@gmail.com','pass@789','Accounts')
insert tbl_Employees values('Sainath','HYD',50000,'03/23/1996','06/22/2016','9948493334','sai@gmail.com','pass@111','TeamLeader')

--Tbl_Employee_Available_Leaves 
--: EmployeeID , SickLeave ,CasualLeave,VacationLeave, CompOff 

create table tbl_Employee_Available_Leaves
(
EmployeeID int foreign key references tbl_Employees(EmployeeID),
SickLeave int not null,
CasualLeave int not null,
VacationLeave int not null,
CompOff int not null
)

insert tbl_Employee_Available_Leaves values(1000,2,5,6,1)
insert tbl_Employee_Available_Leaves values(1001,10,7,16,4)
insert tbl_Employee_Available_Leaves values(1000,5,4,10,5)
insert tbl_Employee_Available_Leaves values(1002,6,7,9,3)
insert tbl_Employee_Available_Leaves values(1003,8,4,7,7)

select * from tbl_Employee_Available_Leaves

--Tbl_EmployeeLeaves 
--: LeaveID,EmployeeID , LeaveType , LeaveApplyDate , LeaveDate , NoOfDays

create table tbl_EmployeeLeaves
(
LeaveID int identity(100,1) primary key,
EmployeeID int foreign key references tbl_Employees(EmployeeID),
LeaveType varchar(100) not null,
LeaveApplyDate datetime not null,
LeaveDate datetime not null,
NoOfDays int not null
)

insert tbl_EmployeeLeaves values(1000,'Sick','03/09/2019','05/09/2019',3)
insert tbl_EmployeeLeaves values(1002,'Vacation','07/19/2018','07/29/2018',10)
insert tbl_EmployeeLeaves values(1001,'Sick','11/29/2017','12/10/2017',11)
insert tbl_EmployeeLeaves values(1001,'Casual','05/18/2018','05/27/2018',9)
insert tbl_EmployeeLeaves values(1000,'CompOff','08/16/2019','08/22/2019',6)

select * from tbl_EmployeeLeaves

--Tbl_EmployeeSalary
--: EmployeeID , EmployeeSalary , SalaryMonth , SalaryYear , SalaryDate

create table tbl_EmployeeSalary
(
EmployeeID int foreign key references tbl_Employees(EmployeeID),
EmployeeSalary int not null,
SalaryMonth int not null,
SalaryYear int not null,
SalaryDate int not null
)

insert tbl_EmployeeSalary values(1000,22000,09,2019,30)
insert tbl_EmployeeSalary values(1001,20000,11,2016,30)
insert tbl_EmployeeSalary values(1001,25000,05,2017,31)
insert tbl_EmployeeSalary values(1000,21000,02,2018,28)
insert tbl_EmployeeSalary values(1002,15000,10,2019,31)

select * from tbl_EmployeeSalary

--Create a List of Employees who are join in the current month

select * from tbl_Employees where datename(mm,EmployeeDOJ)=datename(mm,getdate())

--Create a List of Employees who have more than 20000 salary

select * from tbl_Employees where EmployeeSalary>20000

--Create a List of EmployeeDept with no of employees , total salary , avg salary

select EmployeeDept,sum(EmployeeSalary) as totalsalary,avg(EmployeeSalary) as avgsalary ,
count(*) as noofemployees from tbl_Employees group by EmployeeDept


--Create a List of Employees (EmployeeID , EmployeeName , SickLeave , CasualLeave , VacationLeave , CompOff)

select tbl_Employees.EmployeeID,tbl_Employees.EmployeeName,tbl_Employee_Available_Leaves.SickLeave,
tbl_Employee_Available_Leaves.CasualLeave,tbl_Employee_Available_Leaves.VacationLeave,
tbl_Employee_Available_Leaves.CompOff
from tbl_Employees
join tbl_Employee_Available_Leaves
on
tbl_Employees.EmployeeID=tbl_Employee_Available_Leaves.EmployeeID


--Create a List of Employees (EmployeeID , EmployeeName , EmployeeSalary , SalaryMonth , SalaryDate ) 
--based on specific customerid

select tbl_Employees.EmployeeID,tbl_Employees.EmployeeName,tbl_Employees.EmployeeSalary,
tbl_EmployeeSalary.SalaryMonth,tbl_EmployeeSalary.SalaryDate
from tbl_Employees
join tbl_EmployeeSalary
on
tbl_Employees.EmployeeID=tbl_EmployeeSalary.EmployeeID
where tbl_Employees.EmployeeID=1000

--Create a procedure for adding employee in the table with Tbl_Employee_Available_Leaves details

alter proc proc_employees_available_leaves
(@ename varchar(100),@ecity varchar(100),@esal varchar(100),@edob datetime,@edoj datetime,
@emob varchar(15),@email varchar(100),@epass varchar(100),@edept varchar(100),
@sick varchar(100),@casual varchar(100),@vacation varchar(100),@comp varchar(100))
as
begin
begin tran
begin try
insert tbl_Employees values(@ename,@ecity,@esal,@edob,getdate(),@emob,@email,@epass,@edept)
insert tbl_Employee_Available_Leaves values(@@identity,@sick,@casual,@vacation,@comp)
commit tran
return @@identity
end try
begin catch
rollback tran
return -1
end catch
end

select * from tbl_Employees
select * from tbl_Employee_Available_Leaves
declare @e int
exec @e=proc_employees_available_leaves 'Avinash','BGL',20000,'03/23/1998','9948490034','avi@gmail.com',
'pass@222','Manager',4,5,2,6
select @e


--Create a procedure for adding leave in the leaves table

alter proc pro_addleaves
(@eid int,@ltype varchar(100),@lapplydate datetime,@ldate datetime,@lnoofdays int)
as
begin
insert tbl_EmployeeLeaves values(@eid,@ltype,@lapplydate,@ldate,@lnoofdays)
return @@rowcount
end

declare @l int
exec @l=pro_addleaves 1002,'Vacation','08/23/2019','08/25/2019',9
select @l

select * from tbl_EmployeeLeaves


--Create a trigger for updating leave in the tbl_EmployeeLeaves table when employee take leave

create trigger trg_employeeleaves
on tbl_EmployeeLeaves
for insert
as
begin
declare @lid int
declare @eid int
declare @ltype varchar(100)
declare @lapplydate datetime
declare @ldate datetime
declare @lnoofdays int
select @eid=EmployeeID,@ltype=LeaveType,@lnoofdays=NoOfDays from inserted
if(@ltype='SickLeave')
begin
update tbl_Employee_Available_Leaves set SickLeave=SickLeave-@lnoofdays where EmployeeID=@eid
end
if(@ltype='CasualLeave')
begin
update tbl_Employee_Available_Leaves set CasualLeave=CasualLeave-@lnoofdays where EmployeeID=@eid
end
if(@ltype='VacationLeave')
begin
update tbl_Employee_Available_Leaves set VacationLeave=VacationLeave-@lnoofdays where EmployeeID=@eid
end
if(@ltype='CompOff')
begin
update tbl_Employee_Available_Leaves set CompOff=CompOff-@lnoofdays where EmployeeID=@eid
end
end

insert tbl_EmployeeLeaves values(1001,'sick',getdate(),getdate(),2)

select * from tbl_EmployeeLeaves

--Create a trigger for checking salarymonth and salaryear, if month and year is old than rollback the trigger.
--And also paying salary should not be more than employeesalary

create trigger trg_salarymont
on tbl_employeesalary for insert
as 
begin
declare @salarymonth int
declare @salaryyear int
declare @salary int
declare @eid int
select @salarymonth=salarymonth,@salaryyear=salaryyear,@salary=employeesalary,@eid=employeeid from inserted
declare @empsalary int
select @empsalary=employeesalary from  tbl_employees where employeeid=@eid
if(datepart(yy,getdate())!= @salaryyear and datepart(mm,getdate())!= @salarymonth and @empsalary<=@salary )
begin
rollback tran
end
end

insert tbl_employeesalary values(1001,20000,12,30,18)
select * from tbl_employeesalary
















