create Database batch8_ado

use batch8_ado

create table tbl_employees
(
EmployeeID int identity(1000,1) primary key,
EmployeeName varchar(100) not null,
EmployeeCity varchar(100) not null,
EmployeeSalary int not null,
EmployeePassword varchar(100)
)

--add

create proc proc_addemployee
(@name varchar(100),@city varchar(100),@salary int,@password varchar(100))
as
begin
insert tbl_employees values(@name,@city,@salary,@password)
return @@identity
end

--update

create proc proc_updateemployee
(@id int,@city varchar(100),@salary int)
as
begin
update tbl_employees set EmployeeCity=@city,EmployeeSalary=@salary
where EmployeeID=@id
return @@rowcount
end

--delete

create proc proc_deleteemployee
(@id int)
as
begin
delete tbl_employees where EmployeeID=@id
return @@rowcount
end

--find

create proc proc_findemployee
(@id int)
as
begin
select * from tbl_employees where EmployeeID=@id
end

--search

create proc proc_searchemployee
(@key varchar(100))
as
begin 
select * from tbl_employees where EmployeeID like '%'+@key+'%' or 
								  EmployeeName like '%'+@key+'%' or
								  EmployeeCity like '%'+@key+'%' 
end

--login

create proc proc_login
(@id int,@password varchar(100))
as
begin
declare @count int
select @count=count(*) from tbl_employees
where EmployeeID=@id and EmployeePassword=@password
return @count
end




