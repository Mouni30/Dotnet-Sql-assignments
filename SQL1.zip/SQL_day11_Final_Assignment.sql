--Create a Database named MyBankDB 
-----------------------

create Database MyBankDB

use MyBankDB

--Tables

--tbl_Employees with Auto Gen EmployeeID
--(EmployeeID , EmployeeName , EmployeeCity , EmployeeDesignation , EmployeeDOB , 
--EmployeeDOJ , EmployeeSalary) 

create table tbl_Employees
(
EmployeeID int identity(1000,1) primary key,
EmployeeName varchar(100) not null,
EmployeeCity varchar(100) not null,
EmployeeDesignation varchar(100) not null,
EmployeeDOB datetime not null,
EmployeeDOJ datetime not null,
EmployeeSalary int not null
)

insert tbl_Employees values('Mounika','BGL','HR','11/30/1996','03/12/2018',30000)
insert tbl_Employees values('Bhagya','Chennai','Manager','06/14/1995','08/22/2017',35000)
insert tbl_Employees values('Anil','BGL','CEO','09/28/1996','11/17/2016',40000)
insert tbl_Employees values('Surekha','Chennai','Accounts','01/10/1995','07/18/2018',20000)
insert tbl_Employees values('Sainath','HDY','Finance','03/23/1998','09/27/2018',50000)

select * from tbl_Employees

--tbl_Customers with Auto gen CustomerID
--(CustomerID(PK) , CustomerName, CustomerCity, CustomerAddress , CustomerMobileNo(U), PAN (U), 
--CustomerPassword , CustomerEmailID (U) , ApprovedBy (FK-EmployeeID) )

create table tbl_Customers
(
CustomerID int identity(100,1) primary key,
CustomerName varchar(100) not null,
CustomerCity varchar(100) not null,
CustomerAddress varchar(max) not null,
CustomerMobileNo varchar(15) not null unique,
Pan varchar(100) not null unique,
CustomerPassword varchar(100) not null,
CustomerEmailID varchar(100) not null unique,
EmployeeID int foreign key references tbl_Employees(EmployeeID)
) 

insert tbl_Customers values('John','BGL','JP Nagar','9948498834','EPAN123','pass123','john@gmail.com',1000)
insert tbl_Customers values('Smith','Chennai','MG Road','9948497734','EPAN122','pass122','smith@gmail.com',1001)
insert tbl_Customers values('Rahul','BGL','Basavannagudi','9948496634','EPAN111','pass111','rahul@gmail.com',1000)
insert tbl_Customers values('Ravi','Chennai','Koramangala','9948495534','EPAN121','pass121','ravi@gmail.com',1002)
insert tbl_Customers values('Avi','Pune','BTM','9948494434','EPAN222','pass222','avi@gmail.com',1003)

select * from tbl_Customers

--tbl_AccountInfo with auto gen AccountID
--(AccountID(PK),CustomerID(FK),AccountType,AccountBalance,AccountOpenDate, 
--AccountStatus(Open,Closed,Blocked)) 

create table tbl_AccountInfo
(
AccountID int identity(100000,1) primary key,
CustomerID int foreign key references tbl_Customers(CustomerID),
AccountType varchar(100) not null,
AccountBalance int not null,
AccountOpenDate datetime not null,
AccountStatus varchar(100) not null
)

insert tbl_AccountInfo values(100,'Savings',50000,getdate(),'Open')
insert tbl_AccountInfo values(100,'Current',150000,getdate(),'Closed')
insert tbl_AccountInfo values(101,'Savings',250000,getdate(),'Open')
insert tbl_AccountInfo values(102,'Current',350000,getdate(),'Blocked')
insert tbl_AccountInfo values(103,'Savings',450000,getdate(),'Closed')

select * from tbl_AccountInfo

--tbl_TransactionInfo with Auto gen TransactionID
--(TransactionID (PK),AccountID (FK),TransactionType (D,C), Amount (>0),TransactionDate)

Create Table tbl_TransactionInfo
(
TransactionID int identity(1,1) primary key,
AccountID int foreign key references tbl_AccountInfo(AccountID),
TransactionType varchar(100) not null,
Amount int not null check (Amount>0),
TransactionDate datetime not null
)

insert tbl_TransactionInfo values(100001,'Credit',20000,'12/19/2018')
insert tbl_TransactionInfo values(100001,'Debit',30000,'12/20/2018')
insert tbl_TransactionInfo values(100002,'Credit',25000,'12/20/2018')
insert tbl_TransactionInfo values(100003,'Debit',35000,'12/21/2018')
insert tbl_TransactionInfo values(100004,'Credit',40000,'12/22/2018')

select * from tbl_TransactionInfo


--Latest 5 transactions of an account (Enter Account ID as an Input)
-- Use a Stored Procedure

create procedure proc_transactions
(@tid int)
as
begin
select top 5 * from tbl_TransactionInfo where Accountid=@tid order by TransactionDate desc
end

exec proc_transactions 100001


--Transaction between two dates of an account (Enter Account ID as an Input)
-- Use a Stored Procedure

alter procedure proc_transaction_betweentwodates
(@aid int)
as
begin
select * from tbl_TransactionInfo where accountid=@aid and
 TransactionDate between  '12/20/2016' and getdate()
end

exec proc_transaction_betweentwodates 100001


--List of Accounts of a Customer (Enter Customer ID as an input)
-- Use a Stored Procedure

create procedure proc_accounts_customer
(@cid int)
as
begin
select * from tbl_AccountInfo where CustomerID=@cid
end

exec proc_accounts_customer 100


--List of customers(CustomerID,CustomerName,CustomerAddress,CustomerMobileNo, AccountID , AccountBalance).
-- Use a Stored Procedure

create procedure proc_customer_join
 as
 begin
 select tbl_Customers.CustomerID,tbl_Customers.CustomerName,tbl_Customers.CustomerAddress,
 tbl_Customers.CustomerMobileNo,tbl_AccountInfo.AccountID,tbl_AccountInfo.AccountBalance 
 from tbl_Customers join tbl_AccountInfo
 on tbl_Customers.CustomerID=tbl_AccountInfo.CustomerID
 end

 exec proc_join

 --List of accounts with transactions (AccountID , AccountBalance , TransID , Amount, TransationType).
 -- Use a Stored Procedure

create procedure proc_Account_Transaction_join
as
begin
select tbl_accountinfo.accountid,tbl_accountinfo.accountbalance,tbl_transactioninfo.transactionid,
tbl_transactioninfo.amount,tbl_transactioninfo.transactiontype from tbl_accountinfo join
tbl_transactioninfo on tbl_accountinfo.accountid=tbl_transactioninfo.accountid
end

exec proc_Account_Transaction_join

--List of customers with accounts and transations (CustomerID,CustomerName,CustomerAddress,CustomerMobileNo, AccountID , AccountBalance,TransationID , Amount, TransationType)
-- Use a Stored Procedure

create procedure proc_Customer_Account_Transaction_join
as
begin
select tbl_customers.customerid,tbl_customers.customername,tbl_customers.customeraddress,
tbl_customers.customermobileno,tbl_accountinfo.accountid,tbl_accountinfo.accountbalance,
tbl_transactioninfo.amount,tbl_transactioninfo.transactiontype from tbl_customers join
tbl_accountinfo on tbl_customers.customerid=tbl_accountinfo.customerid join tbl_transactioninfo
on tbl_accountinfo.accountid=tbl_transactioninfo.accountid
end

exec proc_Customer_Account_Transaction_join

--List of Customers who have accounts
-- Use a Stored Procedure

create procedure proc_accounts
as
begin
select * from tbl_customers where customerid in( 
select customerid from tbl_accountinfo)
end

exec proc_accounts

--List of Customer who have no account.
-- Use a Stored Procedure

create procedure proc_no_accounts
as
begin
select * from tbl_customers where customerid not in( 
select customerid from tbl_accountinfo)
end

exec proc_no_accounts

-- List of Account which has transaction.
-- Use a Stored Procedure

create procedure proc_acctransactions
as
begin
select * from tbl_accountinfo where accountid in(
select accountid from tbl_transactioninfo)
end

exec proc_acctransactions


-- List of Account which has no transaction
-- Use a Stored Procedure

create procedure proc_no_transactions
as
begin
select * from tbl_accountinfo where accountid not in(
select accountid from tbl_transactioninfo)
end

exec proc_no_transactions


--Create two views named v_account_saving and v_account_current 

create view v_account_saving
with encryption
as
select * from tbl_accountinfo where accounttype='saving' with check option

select * from v_account_saving


create view v_account_current
with encryption
as
select * from tbl_accountinfo where accounttype='current' with check option

select * from v_account_current

--Create a procedure for getting accountbalance using output parameter  
--by passing accountid as input parameter.


create procedure proc_account_balance(@aid int,@accountbal int output)
as
begin
select @accountbal=accountbalance from tbl_accountinfo where accountid=@aid
end
select * from tbl_AccountInfo
declare @accountbal int
exec proc_account_balance 100002 ,@accountbal output 
select @accountbal


--Create a trigger for updating the account balance as per the type transaction.

create trigger trg_accountbalance
on tbl_TransactionInfo
for
insert
as
begin
declare @aid int
declare @amount int
declare @atype varchar(100)
select @aid=AccountID,@amount=amount,@atype=TransactionType from inserted
declare @accbal int
select @accbal=AccountBalance from tbl_AccountInfo where AccountID=@aid
if(@atype='deposit')
begin
update tbl_AccountInfo set AccountBalance=@accbal+@amount where AccountID=@aid
end
if(@atype='withdraw')
begin
update tbl_AccountInfo set AccountBalance=@accbal-@amount where AccountID=@aid
end
else
begin
rollback tran
end
end

select * from tbl_AccountInfo
select * from tbl_TransactionInfo


--Find the employee details who is getting maximum salary.

select * from tbl_Employees where EmployeeSalary in
(select max(employeesalary) as MaxSalary from tbl_Employees)

--Find the employee details who is getting second maximum salary.

select top 1 * from tbl_Employees where EmployeeSalary in
(select top 2 EmployeeSalary from tbl_Employees order by EmployeeSalary desc)order by EmployeeSalary asc

--Find the account details which has maximum balanace.

select * from tbl_AccountInfo where AccountBalance in
(select max(AccountBalance) as MaxBalance from tbl_AccountInfo)

--Find the account details which has second maximum balance.

select top 1 * from tbl_AccountInfo where AccountBalance in
(select top 2 AccountBalance from tbl_AccountInfo order by AccountBalance desc)order by AccountBalance asc

--Create a List of (EmployeeID , EmployeeName , CustomerID , CustomerName , AccountID , AccountBalance)

select tbl_Employees.EmployeeID,tbl_Employees.EmployeeName,tbl_Customers.CustomerID,
tbl_Customers.CustomerName,tbl_AccountInfo.AccountID,tbl_AccountInfo.AccountBalance
from tbl_Employees
join tbl_Customers
on
tbl_Customers.EmployeeID=tbl_Employees.EmployeeID
join tbl_AccountInfo
on
tbl_AccountInfo.CustomerID=tbl_Customers.CustomerID

--Create a List of (EmployeeDept , NoOfEmployees)

select EmployeeDesignation,count(*) from tbl_Employees group by EmployeeDesignation

--Create a List of (AccountNo , NoOfTransations)

select AccountID,count(*) from tbl_AccountInfo group by AccountID

--










































