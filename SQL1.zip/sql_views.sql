alter view v_customers_bgl
with encryption
as
Select * from tbl_Customers where CustomerCity='BGL'
with check option

select * from v_customers_bgl where CustomerName='Mounika'

update v_customers_bgl set CustomerCity='Mumbai' where CustomerName='Mounika'
select * from v_customers_bgl

delete v_customers_bgl where CustomerEmailID='abc@gmail.com'

insert v_customers_bgl values('y@abc.com','ABCD','Mumbai','98989','Anderi');

select * from tbl_Customers


sp_helptext v_customers_bgl


alter view v_customers_bgl
with encryption, schemabinding
as
Select CustomerEmailID,CustomerName,CustomerAddress from dbo.tbl_Customers where CustomerCity='BGL'
with check option

select * from db_Invoices.dbo.tbl_Customers


create table t1
(
code int,
name varchar(100)
)

insert t1 values(1001,'A');
insert t1 values(1002,'B');

create table t2
(
code int,
city varchar(100)
)

insert t2 values(1001,'BGL');
insert t2 values(1002,'Chennai');

alter view v_joindate
as
select t1.code,t1.name,t2.city from t1 join t2 on t1.code=t2.code 
--with check option

select * from v_joindate 

insert v_joindate values(1003,'C','BGL')


create trigger trg_v_joindata
on v_joindate
instead of insert
as
begin
declare @id int
declare @name varchar(100)
declare @city varchar(100)
select @id=code,@name=name,@city=city from inserted
insert t1 values(@id,@name)
insert t2 values(@id,@city)
end


create table tbl_test
(
code int identity(1,1),
name varchar(100),
city varchar(100)
)

declare @count int =0;
while (@count<100000)
begin
insert tbl_test values('ABCD','BGL');
set @count=@count+1;
end


select * from tbl_test where code=51000

create clustered index idx
on tbl_test(code)

--Transactions
create table xyz
(
code int,
name varchar(5)
)


begin tran tran1
begin try
insert xyz values(11,'ABC')
insert xyz values(22,'ABCD')
commit tran
end try
begin catch
rollback tran
end catch

select * from xyz

begin tran

insert xyz values(111,'ABC')

select * from xyz

rollback tran

commit tran











