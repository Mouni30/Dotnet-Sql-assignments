select * from tb1_Customers

--Create a procedure for adding a row in tbl_Customers table and return customerid
create procedure pro_adding_rows(@cid int,@cname varchar(100),@ccity varchar(100),@cage int)
as
begin
declare @count int =0;
select @count=count(*)from tb1_Customers where customerId=@cid;
if(@count=0)
begin
insert tb1_Customers values(@cid,@cname,@ccity,@cage);
end
return @cid
end

declare @s int
exec @s=pro_adding_rows 1234,'yash','sweden',25
select @s


--Create a procedure for updating customer row based on customerid (update customercity).

create procedure proc_updaing_city(@cid int,@ccity varchar(100))
as
begin
update tb1_customers set CustomerCity=@ccity where customerId=@cid
end

declare @s int
exec @s=proc_updaing_city 1006,'pune'
select @s


--Create a procedure for updating the customermobileno based on customerid and password.
--Procedure must take three parameters (CustomerID , CustomerPassword,NewMobileNo). 
--If CustomerID and CustomerPassword matches then only MobileNo can be updated. 
--Returns 0 or 1 as per the update.

create procedure proc_updating_ages(@cid int,@cname varchar(100),@cage int)
as
begin
update tb1_Customers set CustomerAge=@cage where customerId=@cid and CustomerName=@cname
return @@rowcount
end

declare @s int
exec @s=proc_updating_ages 1003,'saiteja',35
select @s


--Create a procedure for displaying (CustomerID , CustomerName , AccountID , AccountBalance) 
--based on customerid.(use join)

select * from tbl_accounts
create procedure proc_displaying_join
as
begin
select tb1_Customers.customerId,tb1_Customers.customerName,tbl_accounts.accountid,
tbl_accounts. accountbalance from tb1_Customers join tbl_accounts
on  tb1_Customers.CustomerName=tbl_accounts.customername
end

declare @s int
exec @s=proc_displaying_join


--Create a procedure for login (ID & Password) , if user enters three times wrong password on the 
--same day then login should be blocked (return 0 , 1, -1)
--(CustomerID , Password , Name , PasswordCount , Status , WrongPasswordAttemptDate)
-- Add Rows using Procedure 

create table tbl_cust
(
customerid int,
cpassword varchar(100),
customername varchar(100),
passwordcount int,
cstatus varchar(100),
wrongpasswordattemptdate datetime
)

select * from tbl_cust

insert tbl_cust values(1000,'pass@123','Mounika',0,'active',getdate())
insert tbl_cust values(1001,'pass@111','Bhagya',1,'blocked',null)
insert tbl_cust values(1002,'pass@222','Anil',2,'active',getdate())
insert tbl_cust values(1003,'pass@333','Surekha',1,'blocked',null)
insert tbl_cust values(1004,'pass@444','Sainath',0,'active',getdate())

update tbl_cust set passwordcount=0,cstatus='active'
 
create procedure proc_block(@cid int,@cpassword varchar(100))
as
begin
declare @custpass varchar(100);
declare @passcount int;
select @custpass=cpassword,@passcount=passwordcount from tbl_cust where @cid=customerid
if( @custpass!=@cpassword )
begin
update tbl_cust set passwordcount=passwordcount+1,wrongpasswordattemptdate=getdate()
 where @cid=customerid
 update tbl_cust set passwordcount=1 where datediff(dd,wrongpasswordattemptdate,getdate())!=0
if(@passcount=3)
begin
update tbl_cust set cstatus='blocked' where @cid=customerid
return -1
end
return 0
end
else
begin
return 1
end
end

exec proc_block 1001,'mouni'

select * from tbl_cust



--Create a procdure to get customername , customercity using output parameters based on 
--customerid as an input parameter

create procedure proc_getdata(@cid int)
as
begin
select CustomerName,CustomerCity from tb1_Customers where customerId=@cid
end

declare @s int
exec @s=proc_getdata 1005


--Create a function to concatenate customername , customercity , customeraddress and use in a query

create function func_getfulldetail
(@customername varchar(100),@customercity varchar(100),@customerage varchar(100))
returns varchar(max)
as
begin
declare @fulldetails varchar(max)
set @fulldetails=@customername +','+@customercity +','+@customerage
return @fulldetails;
end

select customerId,dbo.func_getfulldetail(CustomerName,CustomerCity,CustomerAge)
as 'full details' from tb1_Customers 


-- Create a function to return account table output with a parameter customerid

create function func_return_table(@cid int)
returns table
as
return select * from tb1_Customers where customerId=@cid
select * from dbo.func_return_table(1005)
select * from transactioninfo
insert transactioninfo values(140,'withdraw',1000,getdate())
select * from accountinfo
select * from customersinfo


--Create a Trigger for updating the account balance in the account table as per the transaction 
--(withdraw / deposit) in the transation table.(Use the Bank Database)


create trigger trig_account_balance
on transactioninfo for insert
as
begin
declare @amount int
declare @accountid int
declare @transactiontype varchar(100)
select @amount=amount,@accountid=accountid,@transactiontype=transactiontype from inserted
if(@transactiontype='deposit')
begin
update accountinfo set accountbalance=accountbalance+@amount where accountid=@accountid
end
if(@transactiontype='withdraw')
begin
update accountinfo set accountbalance=accountbalance-@amount where accountid=@accountid
end
end




