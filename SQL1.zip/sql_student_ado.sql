create database Student_ado

use Student_ado

create table tbl_Students
(
StudentID int identity(1000,1) primary key,
StudentName varchar(100) not null,
StudentCity varchar(100) not null,
StudentAddress varchar(max) not null,
StudentEmailID varchar(100) not null
)

--add

create proc proc_addstudent
(@name varchar(100),@city varchar(100),@address varchar(max),@email varchar(100))
as
begin
insert tbl_Students values(@name,@city,@address,@email)
return @@identity
end

--find

create proc proc_findstudent
(@id int)
as
begin
select * from tbl_Students where StudentID=@id
end

--update

create proc proc_updatestudent
(@id int,@city varchar(100),@address varchar(max))
as
begin
update tbl_Students set StudentCity=@city,StudentAddress=@address
where StudentID=@id
return @@rowcount
end

--delete

create proc proc_deletestudent
(@id int)
as
begin
delete tbl_Students where StudentID=@id
return @@rowcount
end

--search

create proc proc_searchstudent
(@key varchar(100))
as
begin
select * from tbl_Students where StudentID like '%'+@key+'%' or
								 StudentName like '%'+@key+'%' or
								 StudentCity like '%'+@key+'%' or
								 StudentAddress like '%'+@key+'%' or
								 StudentEmailID like '%'+@key+'%'
end



























