﻿namespace Win_Customers_ado
{
    partial class frm_search
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_key = new System.Windows.Forms.Label();
            this.bt_search = new System.Windows.Forms.Button();
            this.txt_key = new System.Windows.Forms.TextBox();
            this.dg_customers = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dg_customers)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_key
            // 
            this.lbl_key.AutoSize = true;
            this.lbl_key.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lbl_key.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_key.Location = new System.Drawing.Point(110, 61);
            this.lbl_key.Name = "lbl_key";
            this.lbl_key.Size = new System.Drawing.Size(125, 25);
            this.lbl_key.TabIndex = 30;
            this.lbl_key.Text = "Enter a Key :";
            this.lbl_key.Click += new System.EventHandler(this.lbl_key_Click);
            // 
            // bt_search
            // 
            this.bt_search.BackColor = System.Drawing.SystemColors.ControlDark;
            this.bt_search.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_search.Location = new System.Drawing.Point(857, 61);
            this.bt_search.Name = "bt_search";
            this.bt_search.Size = new System.Drawing.Size(126, 58);
            this.bt_search.TabIndex = 29;
            this.bt_search.Text = "Search";
            this.bt_search.UseVisualStyleBackColor = false;
            this.bt_search.Click += new System.EventHandler(this.bt_search_Click);
            // 
            // txt_key
            // 
            this.txt_key.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.txt_key.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_key.Location = new System.Drawing.Point(415, 61);
            this.txt_key.Name = "txt_key";
            this.txt_key.Size = new System.Drawing.Size(173, 30);
            this.txt_key.TabIndex = 28;
            // 
            // dg_customers
            // 
            this.dg_customers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_customers.Location = new System.Drawing.Point(46, 169);
            this.dg_customers.Name = "dg_customers";
            this.dg_customers.RowTemplate.Height = 24;
            this.dg_customers.Size = new System.Drawing.Size(1045, 324);
            this.dg_customers.TabIndex = 31;
            // 
            // frm_search
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1141, 522);
            this.Controls.Add(this.dg_customers);
            this.Controls.Add(this.lbl_key);
            this.Controls.Add(this.bt_search);
            this.Controls.Add(this.txt_key);
            this.Name = "frm_search";
            this.Text = "frm_search";
            ((System.ComponentModel.ISupportInitialize)(this.dg_customers)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_key;
        private System.Windows.Forms.Button bt_search;
        private System.Windows.Forms.TextBox txt_key;
        private System.Windows.Forms.DataGridView dg_customers;
    }
}