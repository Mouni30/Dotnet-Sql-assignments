﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Customers_ado
{
    public partial class frm_search : Form
    {
        public frm_search()
        {
            InitializeComponent();
        }

        private void bt_search_Click(object sender, EventArgs e)
        {
            if (txt_key.Text == string.Empty)
            {
                MessageBox.Show("Enter a Key :");
            }
            else
            {
                CustomerDAL dal = new CustomerDAL();
                string key = txt_key.Text;
                List<CustomerModel> list = dal.SearchCustomer(key);
                dg_customers.DataSource = list;
            }
        }

        private void lbl_key_Click(object sender, EventArgs e)
        {

        }
    }
}
