﻿namespace Win_Customers_ado
{
    partial class frm_find
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_customerpassword = new System.Windows.Forms.TextBox();
            this.txt_customercity = new System.Windows.Forms.TextBox();
            this.txt_customeraddress = new System.Windows.Forms.TextBox();
            this.txt_customermobileno = new System.Windows.Forms.TextBox();
            this.txt_customeremailid = new System.Windows.Forms.TextBox();
            this.txt_customerid = new System.Windows.Forms.TextBox();
            this.lbl_customeremailid = new System.Windows.Forms.Label();
            this.lbl_customermobileno = new System.Windows.Forms.Label();
            this.lbl_customeraddress = new System.Windows.Forms.Label();
            this.lbl_customerpassword = new System.Windows.Forms.Label();
            this.lbl_customercity = new System.Windows.Forms.Label();
            this.lbl_customername = new System.Windows.Forms.Label();
            this.bt_update = new System.Windows.Forms.Button();
            this.bt_delete = new System.Windows.Forms.Button();
            this.bt_find = new System.Windows.Forms.Button();
            this.lbl_customerid = new System.Windows.Forms.Label();
            this.txt_customername = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txt_customerpassword
            // 
            this.txt_customerpassword.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.txt_customerpassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customerpassword.Location = new System.Drawing.Point(381, 144);
            this.txt_customerpassword.Name = "txt_customerpassword";
            this.txt_customerpassword.Size = new System.Drawing.Size(173, 30);
            this.txt_customerpassword.TabIndex = 23;
            // 
            // txt_customercity
            // 
            this.txt_customercity.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.txt_customercity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customercity.Location = new System.Drawing.Point(381, 198);
            this.txt_customercity.Name = "txt_customercity";
            this.txt_customercity.Size = new System.Drawing.Size(173, 30);
            this.txt_customercity.TabIndex = 22;
            // 
            // txt_customeraddress
            // 
            this.txt_customeraddress.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.txt_customeraddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customeraddress.Location = new System.Drawing.Point(381, 255);
            this.txt_customeraddress.Name = "txt_customeraddress";
            this.txt_customeraddress.Size = new System.Drawing.Size(173, 30);
            this.txt_customeraddress.TabIndex = 21;
            // 
            // txt_customermobileno
            // 
            this.txt_customermobileno.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.txt_customermobileno.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customermobileno.Location = new System.Drawing.Point(381, 315);
            this.txt_customermobileno.Name = "txt_customermobileno";
            this.txt_customermobileno.Size = new System.Drawing.Size(173, 30);
            this.txt_customermobileno.TabIndex = 20;
            // 
            // txt_customeremailid
            // 
            this.txt_customeremailid.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.txt_customeremailid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customeremailid.Location = new System.Drawing.Point(381, 372);
            this.txt_customeremailid.Name = "txt_customeremailid";
            this.txt_customeremailid.Size = new System.Drawing.Size(173, 30);
            this.txt_customeremailid.TabIndex = 19;
            // 
            // txt_customerid
            // 
            this.txt_customerid.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.txt_customerid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customerid.Location = new System.Drawing.Point(381, 38);
            this.txt_customerid.Name = "txt_customerid";
            this.txt_customerid.Size = new System.Drawing.Size(173, 30);
            this.txt_customerid.TabIndex = 18;
            // 
            // lbl_customeremailid
            // 
            this.lbl_customeremailid.AutoSize = true;
            this.lbl_customeremailid.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lbl_customeremailid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customeremailid.Location = new System.Drawing.Point(72, 375);
            this.lbl_customeremailid.Name = "lbl_customeremailid";
            this.lbl_customeremailid.Size = new System.Drawing.Size(180, 25);
            this.lbl_customeremailid.TabIndex = 17;
            this.lbl_customeremailid.Text = "Customer EmailID :";
            // 
            // lbl_customermobileno
            // 
            this.lbl_customermobileno.AutoSize = true;
            this.lbl_customermobileno.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lbl_customermobileno.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customermobileno.Location = new System.Drawing.Point(72, 320);
            this.lbl_customermobileno.Name = "lbl_customermobileno";
            this.lbl_customermobileno.Size = new System.Drawing.Size(196, 25);
            this.lbl_customermobileno.TabIndex = 16;
            this.lbl_customermobileno.Text = "Customer MobileNo :";
            // 
            // lbl_customeraddress
            // 
            this.lbl_customeraddress.AutoSize = true;
            this.lbl_customeraddress.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lbl_customeraddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customeraddress.Location = new System.Drawing.Point(72, 260);
            this.lbl_customeraddress.Name = "lbl_customeraddress";
            this.lbl_customeraddress.Size = new System.Drawing.Size(186, 25);
            this.lbl_customeraddress.TabIndex = 15;
            this.lbl_customeraddress.Text = "Customer Address :";
            // 
            // lbl_customerpassword
            // 
            this.lbl_customerpassword.AutoSize = true;
            this.lbl_customerpassword.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lbl_customerpassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customerpassword.Location = new System.Drawing.Point(72, 149);
            this.lbl_customerpassword.Name = "lbl_customerpassword";
            this.lbl_customerpassword.Size = new System.Drawing.Size(199, 25);
            this.lbl_customerpassword.TabIndex = 14;
            this.lbl_customerpassword.Text = "Customer Password :";
            // 
            // lbl_customercity
            // 
            this.lbl_customercity.AutoSize = true;
            this.lbl_customercity.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lbl_customercity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customercity.Location = new System.Drawing.Point(72, 203);
            this.lbl_customercity.Name = "lbl_customercity";
            this.lbl_customercity.Size = new System.Drawing.Size(147, 25);
            this.lbl_customercity.TabIndex = 13;
            this.lbl_customercity.Text = "Customer City :";
            // 
            // lbl_customername
            // 
            this.lbl_customername.AutoSize = true;
            this.lbl_customername.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lbl_customername.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customername.Location = new System.Drawing.Point(72, 94);
            this.lbl_customername.Name = "lbl_customername";
            this.lbl_customername.Size = new System.Drawing.Size(165, 25);
            this.lbl_customername.TabIndex = 12;
            this.lbl_customername.Text = "Customer Name :";
            // 
            // bt_update
            // 
            this.bt_update.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.bt_update.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_update.Location = new System.Drawing.Point(77, 438);
            this.bt_update.Name = "bt_update";
            this.bt_update.Size = new System.Drawing.Size(142, 46);
            this.bt_update.TabIndex = 24;
            this.bt_update.Text = "Update";
            this.bt_update.UseVisualStyleBackColor = false;
            this.bt_update.Click += new System.EventHandler(this.bt_update_Click);
            // 
            // bt_delete
            // 
            this.bt_delete.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.bt_delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_delete.Location = new System.Drawing.Point(360, 438);
            this.bt_delete.Name = "bt_delete";
            this.bt_delete.Size = new System.Drawing.Size(124, 46);
            this.bt_delete.TabIndex = 25;
            this.bt_delete.Text = "Delete";
            this.bt_delete.UseVisualStyleBackColor = false;
            this.bt_delete.Click += new System.EventHandler(this.bt_delete_Click);
            // 
            // bt_find
            // 
            this.bt_find.BackColor = System.Drawing.SystemColors.ControlDark;
            this.bt_find.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_find.Location = new System.Drawing.Point(782, 47);
            this.bt_find.Name = "bt_find";
            this.bt_find.Size = new System.Drawing.Size(126, 58);
            this.bt_find.TabIndex = 26;
            this.bt_find.Text = "Find";
            this.bt_find.UseVisualStyleBackColor = false;
            this.bt_find.Click += new System.EventHandler(this.bt_find_Click);
            // 
            // lbl_customerid
            // 
            this.lbl_customerid.AutoSize = true;
            this.lbl_customerid.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lbl_customerid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customerid.Location = new System.Drawing.Point(72, 38);
            this.lbl_customerid.Name = "lbl_customerid";
            this.lbl_customerid.Size = new System.Drawing.Size(132, 25);
            this.lbl_customerid.TabIndex = 27;
            this.lbl_customerid.Text = "Customer ID :";
            // 
            // txt_customername
            // 
            this.txt_customername.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.txt_customername.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customername.Location = new System.Drawing.Point(381, 94);
            this.txt_customername.Name = "txt_customername";
            this.txt_customername.Size = new System.Drawing.Size(173, 30);
            this.txt_customername.TabIndex = 28;
            // 
            // frm_find
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1020, 523);
            this.Controls.Add(this.txt_customername);
            this.Controls.Add(this.lbl_customerid);
            this.Controls.Add(this.bt_find);
            this.Controls.Add(this.bt_delete);
            this.Controls.Add(this.bt_update);
            this.Controls.Add(this.txt_customerpassword);
            this.Controls.Add(this.txt_customercity);
            this.Controls.Add(this.txt_customeraddress);
            this.Controls.Add(this.txt_customermobileno);
            this.Controls.Add(this.txt_customeremailid);
            this.Controls.Add(this.txt_customerid);
            this.Controls.Add(this.lbl_customeremailid);
            this.Controls.Add(this.lbl_customermobileno);
            this.Controls.Add(this.lbl_customeraddress);
            this.Controls.Add(this.lbl_customerpassword);
            this.Controls.Add(this.lbl_customercity);
            this.Controls.Add(this.lbl_customername);
            this.Name = "frm_find";
            this.Text = "frm_find";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_customerpassword;
        private System.Windows.Forms.TextBox txt_customercity;
        private System.Windows.Forms.TextBox txt_customeraddress;
        private System.Windows.Forms.TextBox txt_customermobileno;
        private System.Windows.Forms.TextBox txt_customeremailid;
        private System.Windows.Forms.TextBox txt_customerid;
        private System.Windows.Forms.Label lbl_customeremailid;
        private System.Windows.Forms.Label lbl_customermobileno;
        private System.Windows.Forms.Label lbl_customeraddress;
        private System.Windows.Forms.Label lbl_customerpassword;
        private System.Windows.Forms.Label lbl_customercity;
        private System.Windows.Forms.Label lbl_customername;
        private System.Windows.Forms.Button bt_update;
        private System.Windows.Forms.Button bt_delete;
        private System.Windows.Forms.Button bt_find;
        private System.Windows.Forms.Label lbl_customerid;
        private System.Windows.Forms.TextBox txt_customername;
    }
}