﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Customers_ado
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void bt_newcustomer_Click(object sender, EventArgs e)
        {
            if (txt_customername.Text == string.Empty)
            {
                MessageBox.Show("Enter Name :");
            }
            else if (txt_customerpassword.Text == string.Empty)
            {
                MessageBox.Show("Enter Password :");
            }
            else if (txt_customercity.Text == string.Empty)
            {
                MessageBox.Show("Enter City :");
            }
            else if (txt_customeraddress.Text == string.Empty)
            {
                MessageBox.Show("Enter Address :");
            }
            else if (txt_customermobileno.Text == string.Empty)
            {
                MessageBox.Show("Enter MobileNo :");
            }
            else if (txt_customeremailid.Text == string.Empty)
            {
                MessageBox.Show("Enter Email ID :");
            }
            else
            {
                CustomerModel model = new CustomerModel();
                model.CustomerName = txt_customername.Text;
                model.CustomerPassword = txt_customerpassword.Text;
                model.CustomerCity = txt_customercity.Text;
                model.CustomerAddress = txt_customeraddress.Text;
                model.CustomerMobileNo = txt_customermobileno.Text;
                model.CustomerEmailID = txt_customeremailid.Text;
                CustomerDAL dal = new CustomerDAL();
                int ID = dal.AddCustomer(model);
                MessageBox.Show("Customer Added : ID :" + ID);
            }
        }

        private void bt_login_Click(object sender, EventArgs e)
        {
            if (txt_loginid.Text == string.Empty)
            {
                MessageBox.Show("Enter LoginID :");
            }
            else if (txt_password.Text == string.Empty)
            {
                MessageBox.Show("Enter Password :");
            }
            else
            {
                int LoginID = Convert.ToInt32(txt_loginid.Text);
                string Password = txt_password.Text;
                CustomerDAL dal = new CustomerDAL();
                bool status = dal.Login(LoginID, Password);
                if (status == true)
                {
                    MessageBox.Show("Valid User");
                    frm_home obj = new frm_home();
                    obj.Show();
                }
                else
                {
                    MessageBox.Show("Invalid User");
                }
            }
        }

        private void bt_reset_Click(object sender, EventArgs e)
        {
            txt_customername.Text = string.Empty;
            txt_customerpassword.Text = string.Empty;
            txt_customercity.Text = string.Empty;
            txt_customeraddress.Text = string.Empty;
            txt_customermobileno.Text = string.Empty;
            txt_customeremailid.Text = string.Empty;
        }
    }
}
