﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace Win_Customers_ado
{
    class CustomerDAL
    {
        SqlConnection con = new SqlConnection
            (ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public int AddCustomer(CustomerModel model)
        {
            SqlCommand com_add_customer = new SqlCommand("proc_AddCustomers", con);
            com_add_customer.Parameters.AddWithValue("@name", model.CustomerName);
            com_add_customer.Parameters.AddWithValue("@password", model.CustomerPassword);
            com_add_customer.Parameters.AddWithValue("@city", model.CustomerCity);
            com_add_customer.Parameters.AddWithValue("@address", model.CustomerAddress);
            com_add_customer.Parameters.AddWithValue("@mobileno", model.CustomerMobileNo);
            com_add_customer.Parameters.AddWithValue("@email", model.CustomerEmailID);
            com_add_customer.CommandType = CommandType.StoredProcedure;
            SqlParameter para_return = new SqlParameter();
            para_return.Direction = ParameterDirection.ReturnValue;
            com_add_customer.Parameters.Add(para_return);
            con.Open();
            com_add_customer.ExecuteNonQuery();//Exec Proc
            con.Close();
            int id = Convert.ToInt32(para_return.Value);
            return id;

        }
        public bool UpdateCustomer(int id, string address, string mobileno)
        {
            SqlCommand com_update = new SqlCommand("proc_updatecustomer", con);
            com_update.Parameters.AddWithValue("@id", id);
            com_update.Parameters.AddWithValue("@address", address);
            com_update.Parameters.AddWithValue("@mobileno", mobileno);
            com_update.CommandType = CommandType.StoredProcedure;
            SqlParameter para_return = new SqlParameter();
            para_return.Direction = ParameterDirection.ReturnValue;
            com_update.Parameters.Add(para_return);
            con.Open();
            com_update.ExecuteNonQuery();
            con.Close();
            int count = Convert.ToInt32(para_return.Value);
            if (count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }

        }
        public bool DeleteCustomer(int id)
        {
            SqlCommand com_delete = new SqlCommand("proc_deletecustomer", con);
            com_delete.Parameters.AddWithValue("@id", id);
            com_delete.CommandType = CommandType.StoredProcedure;
            SqlParameter para_return = new SqlParameter();
            para_return.Direction = ParameterDirection.ReturnValue;
            com_delete.Parameters.Add(para_return);
            con.Open();
            com_delete.ExecuteNonQuery();
            con.Close();
            int count = Convert.ToInt32(para_return.Value);
            if (count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool Login(int id, string password)
        {
            SqlCommand com_login = new SqlCommand("proc_login", con);
            com_login.Parameters.AddWithValue("@id", id);
            com_login.Parameters.AddWithValue("@password", password);
            com_login.CommandType = CommandType.StoredProcedure;
            SqlParameter para_return = new SqlParameter();
            para_return.Direction = ParameterDirection.ReturnValue;
            com_login.Parameters.Add(para_return);
            con.Open();
            com_login.ExecuteNonQuery();
            con.Close();
            int count = Convert.ToInt32(para_return.Value);
            if (count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public CustomerModel FindCustomer(int id)
        {
            SqlCommand com_find = new SqlCommand("proc_findcustomer", con);
            com_find.Parameters.AddWithValue("@id", id);
            com_find.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com_find.ExecuteReader();
            if (dr.Read())
            {
                CustomerModel model = new CustomerModel();
                model.CustomerID = dr.GetInt32(0);
                model.CustomerName = dr.GetString(1);
                model.CustomerPassword = dr.GetString(2);
                model.CustomerCity = dr.GetString(3);
                model.CustomerAddress = dr.GetString(4);
                model.CustomerMobileNo = dr.GetString(5);
                model.CustomerEmailID = dr.GetString(6);
                con.Close();
                return model;
            }
            con.Close();
            return null;
        }
        public List<CustomerModel> SearchCustomer(string key)
        {
            SqlCommand com_search = new SqlCommand("proc_searchcustomer", con);
            com_search.Parameters.AddWithValue("@key", key);
            com_search.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com_search.ExecuteReader();
            List<CustomerModel> list = new List<CustomerModel>();
            while (dr.Read())
            {
                CustomerModel model = new CustomerModel();
                model.CustomerID = dr.GetInt32(0);
                model.CustomerName = dr.GetString(1);
                model.CustomerPassword = dr.GetString(2);
                model.CustomerCity = dr.GetString(3);
                model.CustomerAddress = dr.GetString(4);
                model.CustomerMobileNo = dr.GetString(5);
                model.CustomerEmailID = dr.GetString(6);
                list.Add(model);
            }
            con.Close();
            return list;
        }
    }
}
