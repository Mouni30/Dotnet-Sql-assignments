﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Customers_ado
{
    public partial class frm_find : Form
    {
        public frm_find()
        {
            InitializeComponent();
        }

        private void bt_find_Click(object sender, EventArgs e)
        {
            if (txt_customerid.Text == string.Empty)
            {
                MessageBox.Show("Enter ID :");
            }
            else
            {
                int ID = Convert.ToInt32(txt_customerid.Text);
                CustomerDAL dal = new CustomerDAL();
                CustomerModel model = dal.FindCustomer(ID);
                if (model != null)
                {
                    txt_customername.Text = model.CustomerName;
                    txt_customerpassword.Text = model.CustomerPassword;
                    txt_customercity.Text = model.CustomerCity;
                    txt_customeraddress.Text = model.CustomerAddress;
                    txt_customermobileno.Text = model.CustomerMobileNo;
                    txt_customeremailid.Text = model.CustomerEmailID;
                }
                else
                {
                    MessageBox.Show("Customer not found");
                }
            }
        }

        private void bt_update_Click(object sender, EventArgs e)
        {


            int ID = Convert.ToInt32(txt_customerid.Text);
            string address = txt_customeraddress.Text;
            string mobileno = txt_customermobileno.Text;
            CustomerDAL dal = new CustomerDAL();
            bool status = dal.UpdateCustomer(ID, address, mobileno);
            if (status == true)
            {
                MessageBox.Show("Customer Details Updated");
            }
            else
            {
                MessageBox.Show("Not Updated");
            }
        }

        private void bt_delete_Click(object sender, EventArgs e)
        {
            int ID = Convert.ToInt32(txt_customerid.Text);
            CustomerDAL dal = new CustomerDAL();
            bool status = dal.DeleteCustomer(ID);
            if (status == true)
            {
                MessageBox.Show("Customer Deleted");
            }
            else
            {
                MessageBox.Show("Not Deleted");
            }
        }
    }
}
