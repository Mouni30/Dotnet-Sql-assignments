﻿namespace Win_ado1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_employeename = new System.Windows.Forms.Label();
            this.lbl_employeecity = new System.Windows.Forms.Label();
            this.lbl_employeesalary = new System.Windows.Forms.Label();
            this.lbl_employeepassword = new System.Windows.Forms.Label();
            this.txt_employeename = new System.Windows.Forms.TextBox();
            this.txt_employeesalary = new System.Windows.Forms.TextBox();
            this.txt_employeecity = new System.Windows.Forms.TextBox();
            this.txt_employeepassword = new System.Windows.Forms.TextBox();
            this.lbl_loginid = new System.Windows.Forms.Label();
            this.lbl_password = new System.Windows.Forms.Label();
            this.txt_loginid = new System.Windows.Forms.TextBox();
            this.txt_password = new System.Windows.Forms.TextBox();
            this.bt_newemployee = new System.Windows.Forms.Button();
            this.bt_reset = new System.Windows.Forms.Button();
            this.bt_login = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_employeename
            // 
            this.lbl_employeename.AutoSize = true;
            this.lbl_employeename.BackColor = System.Drawing.SystemColors.MenuBar;
            this.lbl_employeename.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_employeename.Location = new System.Drawing.Point(75, 43);
            this.lbl_employeename.Name = "lbl_employeename";
            this.lbl_employeename.Size = new System.Drawing.Size(167, 25);
            this.lbl_employeename.TabIndex = 0;
            this.lbl_employeename.Text = "Employee Name :";
            // 
            // lbl_employeecity
            // 
            this.lbl_employeecity.AutoSize = true;
            this.lbl_employeecity.BackColor = System.Drawing.SystemColors.MenuBar;
            this.lbl_employeecity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_employeecity.Location = new System.Drawing.Point(75, 117);
            this.lbl_employeecity.Name = "lbl_employeecity";
            this.lbl_employeecity.Size = new System.Drawing.Size(149, 25);
            this.lbl_employeecity.TabIndex = 1;
            this.lbl_employeecity.Text = "Employee City :";
            // 
            // lbl_employeesalary
            // 
            this.lbl_employeesalary.AutoSize = true;
            this.lbl_employeesalary.BackColor = System.Drawing.SystemColors.MenuBar;
            this.lbl_employeesalary.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_employeesalary.Location = new System.Drawing.Point(75, 193);
            this.lbl_employeesalary.Name = "lbl_employeesalary";
            this.lbl_employeesalary.Size = new System.Drawing.Size(171, 25);
            this.lbl_employeesalary.TabIndex = 2;
            this.lbl_employeesalary.Text = "Employee Salary :";
            // 
            // lbl_employeepassword
            // 
            this.lbl_employeepassword.AutoSize = true;
            this.lbl_employeepassword.BackColor = System.Drawing.SystemColors.MenuBar;
            this.lbl_employeepassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_employeepassword.Location = new System.Drawing.Point(75, 276);
            this.lbl_employeepassword.Name = "lbl_employeepassword";
            this.lbl_employeepassword.Size = new System.Drawing.Size(201, 25);
            this.lbl_employeepassword.TabIndex = 3;
            this.lbl_employeepassword.Text = "Employee Password :";
            // 
            // txt_employeename
            // 
            this.txt_employeename.BackColor = System.Drawing.SystemColors.MenuBar;
            this.txt_employeename.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_employeename.Location = new System.Drawing.Point(328, 40);
            this.txt_employeename.Name = "txt_employeename";
            this.txt_employeename.Size = new System.Drawing.Size(173, 30);
            this.txt_employeename.TabIndex = 4;
            // 
            // txt_employeesalary
            // 
            this.txt_employeesalary.BackColor = System.Drawing.SystemColors.MenuBar;
            this.txt_employeesalary.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_employeesalary.Location = new System.Drawing.Point(328, 188);
            this.txt_employeesalary.Name = "txt_employeesalary";
            this.txt_employeesalary.Size = new System.Drawing.Size(173, 30);
            this.txt_employeesalary.TabIndex = 5;
            // 
            // txt_employeecity
            // 
            this.txt_employeecity.BackColor = System.Drawing.SystemColors.MenuBar;
            this.txt_employeecity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_employeecity.Location = new System.Drawing.Point(328, 110);
            this.txt_employeecity.Name = "txt_employeecity";
            this.txt_employeecity.Size = new System.Drawing.Size(173, 30);
            this.txt_employeecity.TabIndex = 6;
            // 
            // txt_employeepassword
            // 
            this.txt_employeepassword.BackColor = System.Drawing.SystemColors.MenuBar;
            this.txt_employeepassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_employeepassword.Location = new System.Drawing.Point(328, 273);
            this.txt_employeepassword.Name = "txt_employeepassword";
            this.txt_employeepassword.Size = new System.Drawing.Size(173, 30);
            this.txt_employeepassword.TabIndex = 7;
            // 
            // lbl_loginid
            // 
            this.lbl_loginid.AutoSize = true;
            this.lbl_loginid.BackColor = System.Drawing.SystemColors.MenuBar;
            this.lbl_loginid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_loginid.Location = new System.Drawing.Point(609, 41);
            this.lbl_loginid.Name = "lbl_loginid";
            this.lbl_loginid.Size = new System.Drawing.Size(95, 25);
            this.lbl_loginid.TabIndex = 8;
            this.lbl_loginid.Text = "Login ID :";
            // 
            // lbl_password
            // 
            this.lbl_password.AutoSize = true;
            this.lbl_password.BackColor = System.Drawing.SystemColors.MenuBar;
            this.lbl_password.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_password.Location = new System.Drawing.Point(609, 113);
            this.lbl_password.Name = "lbl_password";
            this.lbl_password.Size = new System.Drawing.Size(109, 25);
            this.lbl_password.TabIndex = 9;
            this.lbl_password.Text = "Password :";
            // 
            // txt_loginid
            // 
            this.txt_loginid.BackColor = System.Drawing.SystemColors.MenuBar;
            this.txt_loginid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_loginid.Location = new System.Drawing.Point(776, 36);
            this.txt_loginid.Name = "txt_loginid";
            this.txt_loginid.Size = new System.Drawing.Size(173, 30);
            this.txt_loginid.TabIndex = 10;
            // 
            // txt_password
            // 
            this.txt_password.BackColor = System.Drawing.SystemColors.MenuBar;
            this.txt_password.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_password.Location = new System.Drawing.Point(776, 108);
            this.txt_password.Name = "txt_password";
            this.txt_password.Size = new System.Drawing.Size(173, 30);
            this.txt_password.TabIndex = 11;
            // 
            // bt_newemployee
            // 
            this.bt_newemployee.BackColor = System.Drawing.SystemColors.MenuBar;
            this.bt_newemployee.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_newemployee.Location = new System.Drawing.Point(80, 390);
            this.bt_newemployee.Name = "bt_newemployee";
            this.bt_newemployee.Size = new System.Drawing.Size(186, 53);
            this.bt_newemployee.TabIndex = 12;
            this.bt_newemployee.Text = "New Employee";
            this.bt_newemployee.UseVisualStyleBackColor = false;
            this.bt_newemployee.Click += new System.EventHandler(this.bt_newemployee_Click);
            // 
            // bt_reset
            // 
            this.bt_reset.BackColor = System.Drawing.SystemColors.MenuBar;
            this.bt_reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_reset.Location = new System.Drawing.Point(317, 390);
            this.bt_reset.Name = "bt_reset";
            this.bt_reset.Size = new System.Drawing.Size(111, 53);
            this.bt_reset.TabIndex = 13;
            this.bt_reset.Text = "Reset";
            this.bt_reset.UseVisualStyleBackColor = false;
            this.bt_reset.Click += new System.EventHandler(this.bt_reset_Click);
            // 
            // bt_login
            // 
            this.bt_login.BackColor = System.Drawing.SystemColors.MenuBar;
            this.bt_login.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_login.Location = new System.Drawing.Point(614, 226);
            this.bt_login.Name = "bt_login";
            this.bt_login.Size = new System.Drawing.Size(160, 54);
            this.bt_login.TabIndex = 14;
            this.bt_login.Text = "Login";
            this.bt_login.UseVisualStyleBackColor = false;
            this.bt_login.Click += new System.EventHandler(this.bt_login_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.MenuBar;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(789, 226);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(160, 54);
            this.button1.TabIndex = 15;
            this.button1.Text = "Login";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(1033, 523);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.bt_login);
            this.Controls.Add(this.bt_reset);
            this.Controls.Add(this.bt_newemployee);
            this.Controls.Add(this.txt_password);
            this.Controls.Add(this.txt_loginid);
            this.Controls.Add(this.lbl_password);
            this.Controls.Add(this.lbl_loginid);
            this.Controls.Add(this.txt_employeepassword);
            this.Controls.Add(this.txt_employeecity);
            this.Controls.Add(this.txt_employeesalary);
            this.Controls.Add(this.txt_employeename);
            this.Controls.Add(this.lbl_employeepassword);
            this.Controls.Add(this.lbl_employeesalary);
            this.Controls.Add(this.lbl_employeecity);
            this.Controls.Add(this.lbl_employeename);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_employeename;
        private System.Windows.Forms.Label lbl_employeecity;
        private System.Windows.Forms.Label lbl_employeesalary;
        private System.Windows.Forms.Label lbl_employeepassword;
        private System.Windows.Forms.TextBox txt_employeename;
        private System.Windows.Forms.TextBox txt_employeesalary;
        private System.Windows.Forms.TextBox txt_employeecity;
        private System.Windows.Forms.TextBox txt_employeepassword;
        private System.Windows.Forms.Label lbl_loginid;
        private System.Windows.Forms.Label lbl_password;
        private System.Windows.Forms.TextBox txt_loginid;
        private System.Windows.Forms.TextBox txt_password;
        private System.Windows.Forms.Button bt_newemployee;
        private System.Windows.Forms.Button bt_reset;
        private System.Windows.Forms.Button bt_login;
        private System.Windows.Forms.Button button1;
    }
}

