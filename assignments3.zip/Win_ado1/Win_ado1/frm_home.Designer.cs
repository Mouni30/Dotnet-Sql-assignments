﻿namespace Win_ado1
{
    partial class frm_home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bt_find = new System.Windows.Forms.Button();
            this.bt_search = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // bt_find
            // 
            this.bt_find.BackColor = System.Drawing.SystemColors.ControlDark;
            this.bt_find.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_find.Location = new System.Drawing.Point(177, 182);
            this.bt_find.Name = "bt_find";
            this.bt_find.Size = new System.Drawing.Size(150, 71);
            this.bt_find.TabIndex = 0;
            this.bt_find.Text = "Find";
            this.bt_find.UseVisualStyleBackColor = false;
            this.bt_find.Click += new System.EventHandler(this.bt_find_Click);
            // 
            // bt_search
            // 
            this.bt_search.BackColor = System.Drawing.SystemColors.ControlDark;
            this.bt_search.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_search.Location = new System.Drawing.Point(548, 182);
            this.bt_search.Name = "bt_search";
            this.bt_search.Size = new System.Drawing.Size(143, 71);
            this.bt_search.TabIndex = 1;
            this.bt_search.Text = "Search";
            this.bt_search.UseVisualStyleBackColor = false;
            this.bt_search.Click += new System.EventHandler(this.bt_search_Click);
            // 
            // frm_home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(929, 525);
            this.Controls.Add(this.bt_search);
            this.Controls.Add(this.bt_find);
            this.Name = "frm_home";
            this.Text = "frm_home";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button bt_find;
        private System.Windows.Forms.Button bt_search;
    }
}