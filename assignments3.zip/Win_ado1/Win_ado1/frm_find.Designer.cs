﻿namespace Win_ado1
{
    partial class frm_find
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_employeepassword = new System.Windows.Forms.TextBox();
            this.txt_employeecity = new System.Windows.Forms.TextBox();
            this.txt_employeesalary = new System.Windows.Forms.TextBox();
            this.txt_employeename = new System.Windows.Forms.TextBox();
            this.lbl_employeepassword = new System.Windows.Forms.Label();
            this.lbl_employeesalary = new System.Windows.Forms.Label();
            this.lbl_employeecity = new System.Windows.Forms.Label();
            this.lbl_employeename = new System.Windows.Forms.Label();
            this.lbl_employeeid = new System.Windows.Forms.Label();
            this.txt_employeeid = new System.Windows.Forms.TextBox();
            this.bt_update = new System.Windows.Forms.Button();
            this.bt_delete = new System.Windows.Forms.Button();
            this.bt_find = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txt_employeepassword
            // 
            this.txt_employeepassword.BackColor = System.Drawing.SystemColors.MenuBar;
            this.txt_employeepassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_employeepassword.Location = new System.Drawing.Point(311, 358);
            this.txt_employeepassword.Name = "txt_employeepassword";
            this.txt_employeepassword.Size = new System.Drawing.Size(173, 30);
            this.txt_employeepassword.TabIndex = 15;
            // 
            // txt_employeecity
            // 
            this.txt_employeecity.BackColor = System.Drawing.SystemColors.MenuBar;
            this.txt_employeecity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_employeecity.Location = new System.Drawing.Point(311, 195);
            this.txt_employeecity.Name = "txt_employeecity";
            this.txt_employeecity.Size = new System.Drawing.Size(173, 30);
            this.txt_employeecity.TabIndex = 14;
            // 
            // txt_employeesalary
            // 
            this.txt_employeesalary.BackColor = System.Drawing.SystemColors.MenuBar;
            this.txt_employeesalary.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_employeesalary.Location = new System.Drawing.Point(311, 273);
            this.txt_employeesalary.Name = "txt_employeesalary";
            this.txt_employeesalary.Size = new System.Drawing.Size(173, 30);
            this.txt_employeesalary.TabIndex = 13;
            // 
            // txt_employeename
            // 
            this.txt_employeename.BackColor = System.Drawing.SystemColors.MenuBar;
            this.txt_employeename.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_employeename.Location = new System.Drawing.Point(311, 125);
            this.txt_employeename.Name = "txt_employeename";
            this.txt_employeename.Size = new System.Drawing.Size(173, 30);
            this.txt_employeename.TabIndex = 12;
            // 
            // lbl_employeepassword
            // 
            this.lbl_employeepassword.AutoSize = true;
            this.lbl_employeepassword.BackColor = System.Drawing.SystemColors.MenuBar;
            this.lbl_employeepassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_employeepassword.Location = new System.Drawing.Point(58, 361);
            this.lbl_employeepassword.Name = "lbl_employeepassword";
            this.lbl_employeepassword.Size = new System.Drawing.Size(201, 25);
            this.lbl_employeepassword.TabIndex = 11;
            this.lbl_employeepassword.Text = "Employee Password :";
            // 
            // lbl_employeesalary
            // 
            this.lbl_employeesalary.AutoSize = true;
            this.lbl_employeesalary.BackColor = System.Drawing.SystemColors.MenuBar;
            this.lbl_employeesalary.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_employeesalary.Location = new System.Drawing.Point(58, 278);
            this.lbl_employeesalary.Name = "lbl_employeesalary";
            this.lbl_employeesalary.Size = new System.Drawing.Size(171, 25);
            this.lbl_employeesalary.TabIndex = 10;
            this.lbl_employeesalary.Text = "Employee Salary :";
            // 
            // lbl_employeecity
            // 
            this.lbl_employeecity.AutoSize = true;
            this.lbl_employeecity.BackColor = System.Drawing.SystemColors.MenuBar;
            this.lbl_employeecity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_employeecity.Location = new System.Drawing.Point(58, 202);
            this.lbl_employeecity.Name = "lbl_employeecity";
            this.lbl_employeecity.Size = new System.Drawing.Size(149, 25);
            this.lbl_employeecity.TabIndex = 9;
            this.lbl_employeecity.Text = "Employee City :";
            // 
            // lbl_employeename
            // 
            this.lbl_employeename.AutoSize = true;
            this.lbl_employeename.BackColor = System.Drawing.SystemColors.MenuBar;
            this.lbl_employeename.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_employeename.Location = new System.Drawing.Point(58, 128);
            this.lbl_employeename.Name = "lbl_employeename";
            this.lbl_employeename.Size = new System.Drawing.Size(167, 25);
            this.lbl_employeename.TabIndex = 8;
            this.lbl_employeename.Text = "Employee Name :";
            // 
            // lbl_employeeid
            // 
            this.lbl_employeeid.AutoSize = true;
            this.lbl_employeeid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_employeeid.Location = new System.Drawing.Point(63, 64);
            this.lbl_employeeid.Name = "lbl_employeeid";
            this.lbl_employeeid.Size = new System.Drawing.Size(134, 25);
            this.lbl_employeeid.TabIndex = 16;
            this.lbl_employeeid.Text = "Employee ID :";
            // 
            // txt_employeeid
            // 
            this.txt_employeeid.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.txt_employeeid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_employeeid.Location = new System.Drawing.Point(311, 58);
            this.txt_employeeid.Name = "txt_employeeid";
            this.txt_employeeid.Size = new System.Drawing.Size(173, 30);
            this.txt_employeeid.TabIndex = 17;
            // 
            // bt_update
            // 
            this.bt_update.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.bt_update.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_update.Location = new System.Drawing.Point(68, 440);
            this.bt_update.Name = "bt_update";
            this.bt_update.Size = new System.Drawing.Size(139, 42);
            this.bt_update.TabIndex = 18;
            this.bt_update.Text = "Update";
            this.bt_update.UseVisualStyleBackColor = false;
            this.bt_update.Click += new System.EventHandler(this.bt_update_Click);
            // 
            // bt_delete
            // 
            this.bt_delete.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.bt_delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_delete.Location = new System.Drawing.Point(299, 440);
            this.bt_delete.Name = "bt_delete";
            this.bt_delete.Size = new System.Drawing.Size(126, 42);
            this.bt_delete.TabIndex = 19;
            this.bt_delete.Text = "Delete";
            this.bt_delete.UseVisualStyleBackColor = false;
            this.bt_delete.Click += new System.EventHandler(this.bt_delete_Click);
            // 
            // bt_find
            // 
            this.bt_find.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.bt_find.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_find.Location = new System.Drawing.Point(631, 46);
            this.bt_find.Name = "bt_find";
            this.bt_find.Size = new System.Drawing.Size(118, 43);
            this.bt_find.TabIndex = 20;
            this.bt_find.Text = "Find";
            this.bt_find.UseVisualStyleBackColor = false;
            this.bt_find.Click += new System.EventHandler(this.bt_find_Click);
            // 
            // frm_find
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(813, 505);
            this.Controls.Add(this.bt_find);
            this.Controls.Add(this.bt_delete);
            this.Controls.Add(this.bt_update);
            this.Controls.Add(this.txt_employeeid);
            this.Controls.Add(this.lbl_employeeid);
            this.Controls.Add(this.txt_employeepassword);
            this.Controls.Add(this.txt_employeecity);
            this.Controls.Add(this.txt_employeesalary);
            this.Controls.Add(this.txt_employeename);
            this.Controls.Add(this.lbl_employeepassword);
            this.Controls.Add(this.lbl_employeesalary);
            this.Controls.Add(this.lbl_employeecity);
            this.Controls.Add(this.lbl_employeename);
            this.Name = "frm_find";
            this.Text = "frm_find";
            this.Load += new System.EventHandler(this.frm_find_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_employeepassword;
        private System.Windows.Forms.TextBox txt_employeecity;
        private System.Windows.Forms.TextBox txt_employeesalary;
        private System.Windows.Forms.TextBox txt_employeename;
        private System.Windows.Forms.Label lbl_employeepassword;
        private System.Windows.Forms.Label lbl_employeesalary;
        private System.Windows.Forms.Label lbl_employeecity;
        private System.Windows.Forms.Label lbl_employeename;
        private System.Windows.Forms.Label lbl_employeeid;
        private System.Windows.Forms.TextBox txt_employeeid;
        private System.Windows.Forms.Button bt_update;
        private System.Windows.Forms.Button bt_delete;
        private System.Windows.Forms.Button bt_find;
    }
}