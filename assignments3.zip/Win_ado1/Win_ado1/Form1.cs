﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_ado1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void bt_newemployee_Click(object sender, EventArgs e)
        {
            if(txt_employeename.Text==string.Empty)
            {
                MessageBox.Show("Enter Name :");
            }
            else if(txt_employeecity.Text==string.Empty)
            {
                MessageBox.Show("Enter City :");
            }
            else if(txt_employeesalary.Text==string.Empty)
            {
                MessageBox.Show("Enter Salary :");
            }
            else if(txt_employeepassword.Text==string.Empty)
            {
                MessageBox.Show("Enter Password :");
            }
            else
            {
                EmployeeModel model = new EmployeeModel();
                model.EmployeeName = txt_employeename.Text;
                model.EmployeeCity = txt_employeecity.Text;
                model.EmployeeSalary =Convert.ToInt32(txt_employeesalary.Text);
                model.EmployeePassword = txt_employeepassword.Text;
                EmployeeDAL dal = new EmployeeDAL();
                int ID = dal.AddEmployee(model);
                MessageBox.Show("Employee Added : ID :" + ID);
            }
        }
        private void bt_login_Click(object sender, EventArgs e)
        {
            if(txt_loginid.Text==string.Empty)
            {
                MessageBox.Show("Enter LoginID :");
            }
            else if(txt_password.Text==string.Empty)
            {
                MessageBox.Show("Enter Password :");
            }
            else
            {
                try
                {
                    int LoginID = Convert.ToInt32(txt_loginid.Text);
                    string Password = txt_password.Text;
                    EmployeeDAL dal = new EmployeeDAL();
                    bool status = dal.Login(LoginID, Password);
                    if (status == true)
                    {
                        MessageBox.Show("Valid User");
                        frm_home obj = new frm_home();
                        obj.Show();
                    }
                    else
                    {
                        MessageBox.Show("Invalid User");
                    }
                }
                catch(System.Data.SqlClient.SqlException exp)
                {
                    MessageBox.Show("Database Error: " + exp.Message);
                }
                catch(Exception exp)
                {
                    MessageBox.Show("Wrong Input :" + exp.Message);
                }
                //finally
                //{
                   MessageBox.Show("Finally Block");
                //}
            }
        }

        private void bt_reset_Click(object sender, EventArgs e)
        {
            txt_employeename.Text = string.Empty;
            txt_employeecity.Text = string.Empty;
            txt_employeesalary.Text = string.Empty;
            txt_employeepassword.Text = string.Empty;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string id = txt_loginid.Text;
            string password = txt_password.Text;
            EmployeeDAL dal = new EmployeeDAL();
            bool status = dal.LoginSQLInjection(id, password);
            if(status==true)
            {
                MessageBox.Show("Valid User");
            }
            else
            {
                MessageBox.Show("Invalid User");
            }
        }
    }
}
