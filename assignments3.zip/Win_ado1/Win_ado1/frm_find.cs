﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_ado1
{
    public partial class frm_find : Form
    {
        public frm_find()
        {
            InitializeComponent();
        }

        private void frm_find_Load(object sender, EventArgs e)
        {

        }

        private void bt_find_Click(object sender, EventArgs e)
        {
            if(txt_employeeid.Text==string.Empty)
            {
                MessageBox.Show("Enter ID :");
            }
            else
            {
                int ID = Convert.ToInt32(txt_employeeid.Text);
                EmployeeDAL dal = new EmployeeDAL();
                EmployeeModel model = dal.FindEmployee(ID);
                if(model!=null)
                {
                    txt_employeename.Text = model.EmployeeName;
                    txt_employeecity.Text = model.EmployeeCity;
                    txt_employeesalary.Text = model.EmployeeSalary.ToString();
                    txt_employeepassword.Text = model.EmployeePassword;
                }
                else
                {
                    MessageBox.Show("Employee not found");
                }

            }
        }

        private void bt_update_Click(object sender, EventArgs e)
        {
            int ID = Convert.ToInt32(txt_employeeid.Text);
            string city = txt_employeecity.Text;
            int salary = Convert.ToInt32(txt_employeesalary.Text);
            EmployeeDAL dal = new EmployeeDAL();
            bool status = dal.UpdateEmployee(ID, city, salary);
            if(status==true)
            {
                MessageBox.Show("Employee Details Updated");
            }
            else
            {
                MessageBox.Show("Not Updated");
            }
        }

        private void bt_delete_Click(object sender, EventArgs e)
        {
            int ID = Convert.ToInt32(txt_employeeid.Text);
            EmployeeDAL dal = new EmployeeDAL();
            bool status = dal.DeleteEmployee(ID);
            if(status==true)
            {
                MessageBox.Show("Employee Deleted");
            }
            else
            {
                MessageBox.Show("Not Deleted");
            }
        }
    }
}
