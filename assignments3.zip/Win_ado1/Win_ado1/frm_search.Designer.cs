﻿namespace Win_ado1
{
    partial class frm_search
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bt_search = new System.Windows.Forms.Button();
            this.txt_key = new System.Windows.Forms.TextBox();
            this.lbl_key = new System.Windows.Forms.Label();
            this.dg_employees = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dg_employees)).BeginInit();
            this.SuspendLayout();
            // 
            // bt_search
            // 
            this.bt_search.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.bt_search.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_search.Location = new System.Drawing.Point(644, 63);
            this.bt_search.Name = "bt_search";
            this.bt_search.Size = new System.Drawing.Size(118, 43);
            this.bt_search.TabIndex = 23;
            this.bt_search.Text = "Search";
            this.bt_search.UseVisualStyleBackColor = false;
            this.bt_search.Click += new System.EventHandler(this.bt_search_Click);
            // 
            // txt_key
            // 
            this.txt_key.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.txt_key.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_key.Location = new System.Drawing.Point(324, 75);
            this.txt_key.Name = "txt_key";
            this.txt_key.Size = new System.Drawing.Size(173, 30);
            this.txt_key.TabIndex = 22;
            // 
            // lbl_key
            // 
            this.lbl_key.AutoSize = true;
            this.lbl_key.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_key.Location = new System.Drawing.Point(76, 81);
            this.lbl_key.Name = "lbl_key";
            this.lbl_key.Size = new System.Drawing.Size(125, 25);
            this.lbl_key.TabIndex = 21;
            this.lbl_key.Text = "Enter a Key :";
            // 
            // dg_employees
            // 
            this.dg_employees.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_employees.Location = new System.Drawing.Point(77, 185);
            this.dg_employees.Name = "dg_employees";
            this.dg_employees.RowTemplate.Height = 24;
            this.dg_employees.Size = new System.Drawing.Size(685, 261);
            this.dg_employees.TabIndex = 24;
            // 
            // frm_search
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(846, 513);
            this.Controls.Add(this.dg_employees);
            this.Controls.Add(this.bt_search);
            this.Controls.Add(this.txt_key);
            this.Controls.Add(this.lbl_key);
            this.Name = "frm_search";
            this.Text = "frm_search";
            ((System.ComponentModel.ISupportInitialize)(this.dg_employees)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bt_search;
        private System.Windows.Forms.TextBox txt_key;
        private System.Windows.Forms.Label lbl_key;
        private System.Windows.Forms.DataGridView dg_employees;
    }
}