﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Linq_Lambda_Employee_Assignment
{
    class EmployeeLeavesJoin
    {
        public int EID { get; set; }
        public string EName { get; set; }
        public int LID { get; set; }
        public string LType { get; set; }
        public string LReason { get; set; }
    }
}
