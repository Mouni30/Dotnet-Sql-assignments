﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Linq_Lambda_Employee_Assignment
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Employee> emplist = new List<Employee>();
            emplist.Add(new Employee { EmployeeID = 1001, EmployeeName = "Mounika", EmployeeSalary = 30000, EmployeeExp = 6, EmployeeCity = "BGL" });
            emplist.Add(new Employee { EmployeeID = 1002, EmployeeName = "Bhagya", EmployeeSalary = 20000, EmployeeExp = 7, EmployeeCity = "Chennai" });
            emplist.Add(new Employee { EmployeeID = 1003, EmployeeName = "Anil", EmployeeSalary = 65000, EmployeeExp = 3, EmployeeCity = "BGL" });
            emplist.Add(new Employee { EmployeeID = 1004, EmployeeName = "Surekha", EmployeeSalary = 55000, EmployeeExp = 5, EmployeeCity = "Chennai" });
            emplist.Add(new Employee { EmployeeID = 1005, EmployeeName = "Sainath", EmployeeSalary = 50000, EmployeeExp = 2, EmployeeCity = "BGL" });
            List<EmployeeLeaves> empleaveslist = new List<EmployeeLeaves>();
            empleaveslist.Add(new EmployeeLeaves { LeaveID = 1, LeaveType = "Casual", Reason = "Marraige", EmployeeID = 1001 });
            empleaveslist.Add(new EmployeeLeaves { LeaveID = 2, LeaveType = "Sick", Reason = "Fever", EmployeeID = 1002 });
            empleaveslist.Add(new EmployeeLeaves { LeaveID = 3, LeaveType = "Vacation", Reason = "Festival", EmployeeID = 1001 });

            //Lambda Expression


            /*
            var data = emplist.Where(e => e.EmployeeCity == "BGL");
            foreach(var d in data)
            {
                Console.WriteLine(d.EmployeeID + " " + d.EmployeeName + " " + d.EmployeeSalary + " " + d.EmployeeExp + " " + d.EmployeeCity);
            }
            */

            /*
            var data = emplist.Where(e => e.EmployeeCity == "BGL").OrderBy(o => o.EmployeeName).ThenByDescending(n => n.EmployeeID);
            foreach(var d in data)
            {
                Console.WriteLine(d.EmployeeID + " " + d.EmployeeName + " "+d.EmployeeCity);
            }
            */

            /*
            var data = emplist.Where(e => e.EmployeeCity == "BGL").Select(s => new EmployeeDetails { EmpID = s.EmployeeID, EmpName = s.EmployeeName, EmpExp = s.EmployeeExp });
            foreach(var d in data)
            {
                Console.WriteLine(d.EmpID + " " + d.EmpName + " " + d.EmpExp);
            }
            */

            /*
            var count = emplist.Count(e => e.EmployeeCity == "BGL");
            Console.WriteLine("Total Employees :" + count);
            */

            /*
            var status = emplist.Exists(e => e.EmployeeID == 1001);
            Console.WriteLine("Employee Exists :" + status);
            */

            /*
            var obj = emplist.FirstOrDefault(e => e.EmployeeID == 1001);
            if(obj!=null)
            {
                Console.WriteLine(obj.EmployeeID + " " + obj.EmployeeName + " " + obj.EmployeeSalary + " " + obj.EmployeeExp + " " + obj.EmployeeCity);
            }
            else
            {
                Console.WriteLine("Employee Not Found");
            }
            */

            /*
            var joindata = emplist.Join(empleaveslist, e => e.EmployeeID, el => el.EmployeeID, (e, el) => new EmployeeLeavesJoin
            {
                EID = e.EmployeeID,
                EName = e.EmployeeName,
                LID = el.LeaveID,
                LType = el.LeaveType,
                LReason = el.Reason
            });
            foreach (var jd in joindata)
            {
                Console.WriteLine(jd.EID + " " + jd.EName + " " + jd.LID + " " + jd.LType + " " + jd.LReason);
            }
            */

            //Linq Queries

            /*
            var data = (from e in emplist
                        where e.EmployeeExp > 5
                        select e).ToList();
            foreach(var d in data)
            {
                Console.WriteLine(d.EmployeeID + " " + d.EmployeeName + " " + d.EmployeeSalary + " " + d.EmployeeExp + " " + d.EmployeeCity);
            }
            */

            /*
            var data = (from e in emplist
                        where e.EmployeeSalary > 50000
                        select e).ToList();
            foreach(var d in data)
            {
                Console.WriteLine(d.EmployeeID + " " + d.EmployeeName + " " + d.EmployeeSalary + " " + d.EmployeeExp + " " + d.EmployeeCity);
            }
            */

            /*
            var data = (from e in emplist
                        where e.EmployeeCity == "BGL"
                        select e).ToList();
            foreach(var d in data)
            {
                Console.WriteLine(d.EmployeeID + " " + d.EmployeeName + " " + d.EmployeeSalary + " " + d.EmployeeExp + " " + d.EmployeeCity);
            }
            */

            /*
            var data = (from e in emplist
                        where e.EmployeeName.StartsWith("A")
                        select new EmployeeDetails { EmpID=e.EmployeeID,EmpName=e.EmployeeName,EmpExp=e.EmployeeExp}).ToList();
            foreach(var d in data)
            {
                Console.WriteLine(d.EmpID + " " + d.EmpName + " " + d.EmpExp);
            }
            */

            /*
            var joindata = (from e in emplist
                            join el in empleaveslist
                            on e.EmployeeID equals el.EmployeeID
                            select new EmployeeLeavesJoin
                            {
                                EID = e.EmployeeID,
                                EName = e.EmployeeName,
                                LID = el.LeaveID,
                                LType = el.LeaveType,
                                LReason = el.Reason
                            }).ToList();
            foreach(var jd in joindata)
            {
                Console.WriteLine(jd.EID + " " + jd.EName + " " + jd.LID + " " + jd.LType + " " + jd.LReason);
            }
            */
            Console.ReadLine();
        }
    }
}
