﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Console_Linq
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Customer> custlist = new List<Customer>();
            custlist.Add(new Customer { CustomerID = 1001, CustomerName = "Mounika", CustomerCity = "BGL" });
            custlist.Add(new Customer { CustomerID = 1002, CustomerName = "Bhagya", CustomerCity = "Chennai" });
            custlist.Add(new Customer { CustomerID = 1003, CustomerName = "Anil", CustomerCity = "BGL" });
            custlist.Add(new Customer { CustomerID = 1004, CustomerName = "Surekha", CustomerCity = "BGL" });
            custlist.Add(new Customer { CustomerID = 1005, CustomerName = "Sainath", CustomerCity = "Chennai" });
            List<Order> orderlist = new List<Order>();
            orderlist.Add(new Order { OrderID = 1, ItemName = "Laptop", ItemQty = 1, ItemPrice = 50000, CustomerID = 1002 });
            orderlist.Add(new Order { OrderID = 2, ItemName = "Mobile", ItemQty = 2, ItemPrice = 30000, CustomerID = 1003 });
            orderlist.Add(new Order { OrderID = 3, ItemName = "TV", ItemQty = 1, ItemPrice = 70000, CustomerID = 1003 });


            //Lambda Expression

            /*
            var data = custlist.Where(c => c.CustomerCity == "BGL");
            foreach(var d in data)
            {
                Console.WriteLine(d.CustomerID + " " + d.CustomerName + " " + d.CustomerCity);
            }
            */

            /*
            var data = custlist.Where(c => c.CustomerCity == "BGL").OrderBy(o => o.CustomerName).ThenByDescending(n => n.CustomerID);
            foreach(var d in data)
            {
                Console.WriteLine(d.CustomerID + " " + d.CustomerName + " " + d.CustomerCity);
            }
            */

            /*
            
            var data = custlist.Where(c => c.CustomerCity == "BGL").Select(s => new CustomerDetails { CustomerID = s.CustomerID, CustomerName = s.CustomerName });
            foreach(var d in data)
            {
                Console.WriteLine(d.CustomerID + " " + d.CustomerName);
            }
            */

            /*
            var count = custlist.Count(c => c.CustomerCity == "BGL");
            Console.WriteLine("Total Customers :" + count);
            */

            /*
            var status = custlist.Exists(c => c.CustomerID == 1001);
            Console.WriteLine("Customer Exists :" + status);
            */

            /*
            var obj = custlist.FirstOrDefault(c => c.CustomerID == 1001);
            if(obj!=null)
            {
                Console.WriteLine(obj.CustomerID + " " + obj.CustomerName + " " + obj.CustomerCity);
            }
            else
            {
                Console.WriteLine("Customer Not Found");
            }
            */

            /*
            var joindata = custlist.Join(orderlist, c => c.CustomerID, o => o.CustomerID, (c, o) => new CustomerOrder
            {
                CID = c.CustomerID,
                CName = c.CustomerName,
                OID = o.OrderID,
                IName = o.ItemName,
                IQty = o.ItemQty,
                IPrice = o.ItemPrice,
                OrderAmt = o.ItemQty * o.ItemPrice
            });
            foreach(var jd in joindata)
            {
                Console.WriteLine(jd.CID + " " + jd.CName + " " + jd.OID + " " + jd.IName + " " + jd.IQty + " " + jd.IPrice + " " + jd.OrderAmt);
            }
            */

            var gb = orderlist.GroupBy(g => g.CustomerID).Select(s => new OrderGroup
            {
                CustomerID = s.Key,
                NoOfOrders = s.Count(),
                OrderSum = s.Sum(ss => ss.ItemPrice * ss.ItemQty)
            });
            foreach(var g in gb)
            {
                Console.WriteLine(g.CustomerID + " " + g.OrderSum + " " + g.NoOfOrders);
            }










            
            
            //Linq Queries
            /*
            var data = (from c in custlist
                        where c.CustomerCity == "Chennai"
                        select c).ToList();
            foreach(var d in data)
            {
                Console.WriteLine(d.CustomerID + " " + d.CustomerName + " " + d.CustomerCity);
            }
            */

            /*
            var data = (from c in custlist
                        where c.CustomerCity == "BGL"
                        select new CustomerDetails { CustomerID = c.CustomerID, CustomerName = c.CustomerName }).ToList();
            foreach(var d in data)
            {
                Console.WriteLine(d.CustomerID + " " + d.CustomerName);
            }
            */

            /*
            var data = (from c in custlist
                        orderby c.CustomerCity ascending
                        select c).ToList();
            foreach(var d in data)
            {
                Console.WriteLine(d.CustomerID + " " + d.CustomerName + " " + d.CustomerCity);
            }
            */

            /*
            var count = (from c in custlist
                         where c.CustomerCity == "BGL"
                         select c).Count();
            Console.WriteLine("Total Customers :" + count);

            var obj = (from c in custlist
                           where c.CustomerID == 1001
                           select c).FirstOrDefault();
            if(obj!=null)
            {
                Console.WriteLine(obj.CustomerID + " " + obj.CustomerName + " " + obj.CustomerCity);
            }
            else
            {
                Console.WriteLine("Customer Not Found");
            }
            */

            /*
            var joindata = (from c in custlist
                            join o in orderlist
         on c.CustomerID equals o.CustomerID
                            select new CustomerOrder
                            {
                                CID = c.CustomerID,
                                CName = c.CustomerName,
                                OID = o.OrderID,
                                IName = o.ItemName,
                                IQty = o.ItemQty,
                                IPrice = o.ItemPrice,
                                OrderAmt = o.ItemQty * o.ItemPrice
                            }).ToList();
            foreach (var j in joindata)
            {
                Console.WriteLine(j.CID + " " + j.CName + " " + j.OID + " " + j.IName + " " + j.IQty + " " + j.IPrice + " " + j.OrderAmt);
            }
            */
            /*
            XDocument xml = XDocument.Load(@"C:\DotnetBatch8\Console_Linq\Console_Linq\CustomersData.xml");
            var data = (from x in xml.Descendants("Customer")
                       select new Customer {CustomerID=Convert.ToInt32(x.Element("CustomerID").Value),
                       CustomerName=x.Element("CustomerName").Value,
                       CustomerCity=x.Element("CustomerCity").Value}).ToList();
            foreach(var d in data)
            {
                Console.WriteLine(d.CustomerID + " " + d.CustomerName + " " + d.CustomerCity);
            }*/

            Console.ReadLine();
        }
    }
}
