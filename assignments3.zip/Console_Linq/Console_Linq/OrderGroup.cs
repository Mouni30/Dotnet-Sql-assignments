﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Linq
{
    class OrderGroup
    {
        public int CustomerID { get; set; }
        public int OrderSum { get; set; }
        public int NoOfOrders { get; set; }
    }
}
