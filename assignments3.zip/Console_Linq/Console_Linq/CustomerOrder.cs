﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Linq
{
    class CustomerOrder
    {
        public int CID { get; set; }
        public string CName { get; set; }
        public int OID { get; set; }
        public string IName { get; set; }
        public int IQty { get; set; }
        public int IPrice { get; set; }
        public int OrderAmt { get; set; }
    }
}
