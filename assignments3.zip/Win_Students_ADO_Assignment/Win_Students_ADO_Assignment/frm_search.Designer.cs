﻿namespace Win_Students_ADO_Assignment
{
    partial class frm_search
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bt_search = new System.Windows.Forms.Button();
            this.txt_key = new System.Windows.Forms.TextBox();
            this.lbl_key = new System.Windows.Forms.Label();
            this.dg_students = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dg_students)).BeginInit();
            this.SuspendLayout();
            // 
            // bt_search
            // 
            this.bt_search.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.bt_search.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_search.Location = new System.Drawing.Point(824, 62);
            this.bt_search.Name = "bt_search";
            this.bt_search.Size = new System.Drawing.Size(136, 57);
            this.bt_search.TabIndex = 22;
            this.bt_search.Text = "Search";
            this.bt_search.UseVisualStyleBackColor = false;
            this.bt_search.Click += new System.EventHandler(this.bt_search_Click);
            // 
            // txt_key
            // 
            this.txt_key.BackColor = System.Drawing.SystemColors.ControlDark;
            this.txt_key.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_key.Location = new System.Drawing.Point(324, 59);
            this.txt_key.Name = "txt_key";
            this.txt_key.Size = new System.Drawing.Size(249, 30);
            this.txt_key.TabIndex = 21;
            // 
            // lbl_key
            // 
            this.lbl_key.AutoSize = true;
            this.lbl_key.BackColor = System.Drawing.SystemColors.ControlDark;
            this.lbl_key.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_key.Location = new System.Drawing.Point(108, 59);
            this.lbl_key.Name = "lbl_key";
            this.lbl_key.Size = new System.Drawing.Size(125, 25);
            this.lbl_key.TabIndex = 20;
            this.lbl_key.Text = "Enter a Key :";
            // 
            // dg_students
            // 
            this.dg_students.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_students.Location = new System.Drawing.Point(62, 183);
            this.dg_students.Name = "dg_students";
            this.dg_students.RowTemplate.Height = 24;
            this.dg_students.Size = new System.Drawing.Size(991, 304);
            this.dg_students.TabIndex = 23;
            // 
            // frm_search
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1106, 516);
            this.Controls.Add(this.dg_students);
            this.Controls.Add(this.bt_search);
            this.Controls.Add(this.txt_key);
            this.Controls.Add(this.lbl_key);
            this.Name = "frm_search";
            this.Text = "frm_search";
            ((System.ComponentModel.ISupportInitialize)(this.dg_students)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bt_search;
        private System.Windows.Forms.TextBox txt_key;
        private System.Windows.Forms.Label lbl_key;
        private System.Windows.Forms.DataGridView dg_students;
    }
}