﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Students_ADO_Assignment
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void bt_newstudent_Click(object sender, EventArgs e)
        {
            if(txt_studentname.Text==string.Empty)
            {
                MessageBox.Show("Enter Name :");
            }
            else if (txt_studentcity.Text == string.Empty)
            {
                MessageBox.Show("Enter City :");
            }
            else if (txt_studentaddress.Text == string.Empty)
            {
                MessageBox.Show("Enter Address :");
            }
            else if (txt_studentemailid.Text == string.Empty)
            {
                MessageBox.Show("Enter EmailID :");
            }
            else
            {
                try
                {
                    StudentModel model = new StudentModel();
                    model.StudentName = txt_studentname.Text;
                    model.StudenCity = txt_studentcity.Text;
                    model.StudentAddress = txt_studentaddress.Text;
                    model.StudentEmailID = txt_studentemailid.Text;
                    StudentDAL dal = new StudentDAL();
                    int id = dal.AddStudent(model);
                    MessageBox.Show("Student Added :" + id);
                }
                finally
                {
                    MessageBox.Show("Finally Block");
                }
            }
        }

        private void bt_reset_Click(object sender, EventArgs e)
        {
            txt_studentname.Text = string.Empty;
            txt_studentcity.Text = string.Empty;
            txt_studentaddress.Text = string.Empty;
            txt_studentemailid.Text = string.Empty;
        }

        private void bt_find_Click(object sender, EventArgs e)
        {
            frm_find obj = new frm_find();
            obj.Show();
        }

        private void bt_search_Click(object sender, EventArgs e)
        {
            frm_search obj = new frm_search();
            obj.Show();
        }
    }
}
