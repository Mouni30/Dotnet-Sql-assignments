﻿namespace Win_Students_ADO_Assignment
{
    partial class frm_find
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_studentid = new System.Windows.Forms.Label();
            this.txt_studentid = new System.Windows.Forms.TextBox();
            this.bt_find = new System.Windows.Forms.Button();
            this.txt_studentemailid = new System.Windows.Forms.TextBox();
            this.txt_studentaddress = new System.Windows.Forms.TextBox();
            this.txt_studentcity = new System.Windows.Forms.TextBox();
            this.txt_studentname = new System.Windows.Forms.TextBox();
            this.lbl_studentemailid = new System.Windows.Forms.Label();
            this.lbl_studentaddress = new System.Windows.Forms.Label();
            this.lbl_studentcity = new System.Windows.Forms.Label();
            this.lbl_studentname = new System.Windows.Forms.Label();
            this.bt_update = new System.Windows.Forms.Button();
            this.bt_delete = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_studentid
            // 
            this.lbl_studentid.AutoSize = true;
            this.lbl_studentid.BackColor = System.Drawing.SystemColors.ControlDark;
            this.lbl_studentid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_studentid.Location = new System.Drawing.Point(88, 45);
            this.lbl_studentid.Name = "lbl_studentid";
            this.lbl_studentid.Size = new System.Drawing.Size(115, 25);
            this.lbl_studentid.TabIndex = 0;
            this.lbl_studentid.Text = "Student ID :";
            // 
            // txt_studentid
            // 
            this.txt_studentid.BackColor = System.Drawing.SystemColors.ControlDark;
            this.txt_studentid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_studentid.Location = new System.Drawing.Point(304, 45);
            this.txt_studentid.Name = "txt_studentid";
            this.txt_studentid.Size = new System.Drawing.Size(249, 30);
            this.txt_studentid.TabIndex = 1;
            // 
            // bt_find
            // 
            this.bt_find.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.bt_find.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_find.Location = new System.Drawing.Point(804, 48);
            this.bt_find.Name = "bt_find";
            this.bt_find.Size = new System.Drawing.Size(136, 57);
            this.bt_find.TabIndex = 19;
            this.bt_find.Text = "Find";
            this.bt_find.UseVisualStyleBackColor = false;
            this.bt_find.Click += new System.EventHandler(this.bt_find_Click);
            // 
            // txt_studentemailid
            // 
            this.txt_studentemailid.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.txt_studentemailid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_studentemailid.Location = new System.Drawing.Point(304, 297);
            this.txt_studentemailid.Name = "txt_studentemailid";
            this.txt_studentemailid.Size = new System.Drawing.Size(249, 30);
            this.txt_studentemailid.TabIndex = 18;
            // 
            // txt_studentaddress
            // 
            this.txt_studentaddress.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.txt_studentaddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_studentaddress.Location = new System.Drawing.Point(304, 236);
            this.txt_studentaddress.Name = "txt_studentaddress";
            this.txt_studentaddress.Size = new System.Drawing.Size(249, 30);
            this.txt_studentaddress.TabIndex = 17;
            // 
            // txt_studentcity
            // 
            this.txt_studentcity.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.txt_studentcity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_studentcity.Location = new System.Drawing.Point(304, 164);
            this.txt_studentcity.Name = "txt_studentcity";
            this.txt_studentcity.Size = new System.Drawing.Size(249, 30);
            this.txt_studentcity.TabIndex = 16;
            // 
            // txt_studentname
            // 
            this.txt_studentname.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.txt_studentname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_studentname.Location = new System.Drawing.Point(304, 101);
            this.txt_studentname.Name = "txt_studentname";
            this.txt_studentname.Size = new System.Drawing.Size(249, 30);
            this.txt_studentname.TabIndex = 15;
            // 
            // lbl_studentemailid
            // 
            this.lbl_studentemailid.AutoSize = true;
            this.lbl_studentemailid.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.lbl_studentemailid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_studentemailid.Location = new System.Drawing.Point(88, 303);
            this.lbl_studentemailid.Name = "lbl_studentemailid";
            this.lbl_studentemailid.Size = new System.Drawing.Size(163, 25);
            this.lbl_studentemailid.TabIndex = 14;
            this.lbl_studentemailid.Text = "Student EmailID :";
            // 
            // lbl_studentaddress
            // 
            this.lbl_studentaddress.AutoSize = true;
            this.lbl_studentaddress.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.lbl_studentaddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_studentaddress.Location = new System.Drawing.Point(88, 241);
            this.lbl_studentaddress.Name = "lbl_studentaddress";
            this.lbl_studentaddress.Size = new System.Drawing.Size(169, 25);
            this.lbl_studentaddress.TabIndex = 13;
            this.lbl_studentaddress.Text = "Student Address :";
            // 
            // lbl_studentcity
            // 
            this.lbl_studentcity.AutoSize = true;
            this.lbl_studentcity.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.lbl_studentcity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_studentcity.Location = new System.Drawing.Point(88, 164);
            this.lbl_studentcity.Name = "lbl_studentcity";
            this.lbl_studentcity.Size = new System.Drawing.Size(130, 25);
            this.lbl_studentcity.TabIndex = 12;
            this.lbl_studentcity.Text = "Student City :";
            // 
            // lbl_studentname
            // 
            this.lbl_studentname.AutoSize = true;
            this.lbl_studentname.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.lbl_studentname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_studentname.Location = new System.Drawing.Point(88, 101);
            this.lbl_studentname.Name = "lbl_studentname";
            this.lbl_studentname.Size = new System.Drawing.Size(148, 25);
            this.lbl_studentname.TabIndex = 11;
            this.lbl_studentname.Text = "Student Name :";
            // 
            // bt_update
            // 
            this.bt_update.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.bt_update.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_update.Location = new System.Drawing.Point(93, 408);
            this.bt_update.Name = "bt_update";
            this.bt_update.Size = new System.Drawing.Size(192, 57);
            this.bt_update.TabIndex = 20;
            this.bt_update.Text = "Update";
            this.bt_update.UseVisualStyleBackColor = false;
            this.bt_update.Click += new System.EventHandler(this.bt_update_Click);
            // 
            // bt_delete
            // 
            this.bt_delete.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.bt_delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_delete.Location = new System.Drawing.Point(390, 408);
            this.bt_delete.Name = "bt_delete";
            this.bt_delete.Size = new System.Drawing.Size(200, 57);
            this.bt_delete.TabIndex = 21;
            this.bt_delete.Text = "Delete";
            this.bt_delete.UseVisualStyleBackColor = false;
            this.bt_delete.Click += new System.EventHandler(this.bt_delete_Click);
            // 
            // frm_find
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1075, 514);
            this.Controls.Add(this.bt_delete);
            this.Controls.Add(this.bt_update);
            this.Controls.Add(this.bt_find);
            this.Controls.Add(this.txt_studentemailid);
            this.Controls.Add(this.txt_studentaddress);
            this.Controls.Add(this.txt_studentcity);
            this.Controls.Add(this.txt_studentname);
            this.Controls.Add(this.lbl_studentemailid);
            this.Controls.Add(this.lbl_studentaddress);
            this.Controls.Add(this.lbl_studentcity);
            this.Controls.Add(this.lbl_studentname);
            this.Controls.Add(this.txt_studentid);
            this.Controls.Add(this.lbl_studentid);
            this.Name = "frm_find";
            this.Text = "frm_find";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_studentid;
        private System.Windows.Forms.TextBox txt_studentid;
        private System.Windows.Forms.Button bt_find;
        private System.Windows.Forms.TextBox txt_studentemailid;
        private System.Windows.Forms.TextBox txt_studentaddress;
        private System.Windows.Forms.TextBox txt_studentcity;
        private System.Windows.Forms.TextBox txt_studentname;
        private System.Windows.Forms.Label lbl_studentemailid;
        private System.Windows.Forms.Label lbl_studentaddress;
        private System.Windows.Forms.Label lbl_studentcity;
        private System.Windows.Forms.Label lbl_studentname;
        private System.Windows.Forms.Button bt_update;
        private System.Windows.Forms.Button bt_delete;
    }
}