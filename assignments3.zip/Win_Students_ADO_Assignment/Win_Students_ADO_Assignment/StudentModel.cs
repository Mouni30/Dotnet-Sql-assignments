﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Win_Students_ADO_Assignment
{
    class StudentModel
    {
        public int StudentID { get; set; }
        public string StudentName { get; set; }
        public string StudenCity { get; set; }
        public string StudentAddress { get; set; }
        public string StudentEmailID { get; set; }
    }
}
