﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace Win_Students_ADO_Assignment
{
    class StudentDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public int AddStudent(StudentModel model)
        {
            SqlCommand com_add = new SqlCommand("proc_addstudent", con);
            com_add.Parameters.AddWithValue("@name", model.StudentName);
            com_add.Parameters.AddWithValue("@city", model.StudenCity);
            com_add.Parameters.AddWithValue("@address", model.StudentAddress);
            com_add.Parameters.AddWithValue("@email", model.StudentEmailID);
            com_add.CommandType = CommandType.StoredProcedure;
            SqlParameter para_return = new SqlParameter();
            para_return.Direction = ParameterDirection.ReturnValue;
            com_add.Parameters.Add(para_return);
            con.Open();
            com_add.ExecuteNonQuery();
            con.Close();
            int id = Convert.ToInt32(para_return.Value);
            return id;
        }
        public bool UpdateStudent(int id,string city,string address)
        {
            SqlCommand com_update = new SqlCommand("proc_updatestudent", con);
            com_update.Parameters.AddWithValue("@id", id);
            com_update.Parameters.AddWithValue("@city", city);
            com_update.Parameters.AddWithValue("@address", address);
            com_update.CommandType = CommandType.StoredProcedure;
            SqlParameter para_return = new SqlParameter();
            para_return.Direction = ParameterDirection.ReturnValue;
            com_update.Parameters.Add(para_return);
            con.Open();
            com_update.ExecuteNonQuery();
            con.Close();
            int count = Convert.ToInt32(para_return.Value);
            if(count>0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool DeleteStudent(int id)
        {
            SqlCommand com_delete = new SqlCommand("proc_deletestudent", con);
            com_delete.Parameters.AddWithValue("@id", id);
            com_delete.CommandType = CommandType.StoredProcedure;
            SqlParameter para_return = new SqlParameter();
            para_return.Direction = ParameterDirection.ReturnValue;
            com_delete.Parameters.Add(para_return);
            con.Open();
            com_delete.ExecuteNonQuery();
            con.Close();
            int count = Convert.ToInt32(para_return.Value);
            if(count>0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public StudentModel FindStudent(int id)
        {
                SqlCommand com_find = new SqlCommand("proc_findstudent", con);
                com_find.Parameters.AddWithValue("@id", id);
                com_find.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader dr = com_find.ExecuteReader();
                if (dr.Read())
                {
                    StudentModel model = new StudentModel();
                    model.StudentID = dr.GetInt32(0);
                    model.StudentName = dr.GetString(1);
                    model.StudenCity = dr.GetString(2);
                    model.StudentAddress = dr.GetString(3);
                    model.StudentEmailID = dr.GetString(4);
                    con.Close();
                    return model;
                }
                con.Close();
                return null;
            }
        public List<StudentModel> SearchStudent(string key)
        {
            SqlCommand com_search = new SqlCommand("proc_searchstudent", con);
            com_search.Parameters.AddWithValue("@key", key);
            com_search.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com_search.ExecuteReader();
            List<StudentModel> list = new List<StudentModel>();
            while (dr.Read())
            {
                StudentModel model = new StudentModel();
                model.StudentID = dr.GetInt32(0);
                model.StudentName = dr.GetString(1);
                model.StudenCity = dr.GetString(2);
                model.StudentAddress = dr.GetString(3);
                model.StudentEmailID = dr.GetString(4);
                list.Add(model);
            }
            con.Close();
            return list;
        }
    }
}
