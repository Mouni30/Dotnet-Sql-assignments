﻿namespace Win_Students_ADO_Assignment
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_studentname = new System.Windows.Forms.Label();
            this.lbl_studentcity = new System.Windows.Forms.Label();
            this.lbl_studentaddress = new System.Windows.Forms.Label();
            this.lbl_studentemailid = new System.Windows.Forms.Label();
            this.txt_studentname = new System.Windows.Forms.TextBox();
            this.txt_studentcity = new System.Windows.Forms.TextBox();
            this.txt_studentaddress = new System.Windows.Forms.TextBox();
            this.txt_studentemailid = new System.Windows.Forms.TextBox();
            this.bt_newstudent = new System.Windows.Forms.Button();
            this.bt_reset = new System.Windows.Forms.Button();
            this.bt_find = new System.Windows.Forms.Button();
            this.bt_search = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_studentname
            // 
            this.lbl_studentname.AutoSize = true;
            this.lbl_studentname.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.lbl_studentname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_studentname.Location = new System.Drawing.Point(79, 72);
            this.lbl_studentname.Name = "lbl_studentname";
            this.lbl_studentname.Size = new System.Drawing.Size(148, 25);
            this.lbl_studentname.TabIndex = 0;
            this.lbl_studentname.Text = "Student Name :";
            // 
            // lbl_studentcity
            // 
            this.lbl_studentcity.AutoSize = true;
            this.lbl_studentcity.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.lbl_studentcity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_studentcity.Location = new System.Drawing.Point(79, 135);
            this.lbl_studentcity.Name = "lbl_studentcity";
            this.lbl_studentcity.Size = new System.Drawing.Size(130, 25);
            this.lbl_studentcity.TabIndex = 1;
            this.lbl_studentcity.Text = "Student City :";
            // 
            // lbl_studentaddress
            // 
            this.lbl_studentaddress.AutoSize = true;
            this.lbl_studentaddress.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.lbl_studentaddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_studentaddress.Location = new System.Drawing.Point(79, 212);
            this.lbl_studentaddress.Name = "lbl_studentaddress";
            this.lbl_studentaddress.Size = new System.Drawing.Size(169, 25);
            this.lbl_studentaddress.TabIndex = 2;
            this.lbl_studentaddress.Text = "Student Address :";
            // 
            // lbl_studentemailid
            // 
            this.lbl_studentemailid.AutoSize = true;
            this.lbl_studentemailid.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.lbl_studentemailid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_studentemailid.Location = new System.Drawing.Point(79, 274);
            this.lbl_studentemailid.Name = "lbl_studentemailid";
            this.lbl_studentemailid.Size = new System.Drawing.Size(163, 25);
            this.lbl_studentemailid.TabIndex = 3;
            this.lbl_studentemailid.Text = "Student EmailID :";
            // 
            // txt_studentname
            // 
            this.txt_studentname.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.txt_studentname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_studentname.Location = new System.Drawing.Point(295, 72);
            this.txt_studentname.Name = "txt_studentname";
            this.txt_studentname.Size = new System.Drawing.Size(249, 30);
            this.txt_studentname.TabIndex = 4;
            // 
            // txt_studentcity
            // 
            this.txt_studentcity.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.txt_studentcity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_studentcity.Location = new System.Drawing.Point(295, 135);
            this.txt_studentcity.Name = "txt_studentcity";
            this.txt_studentcity.Size = new System.Drawing.Size(249, 30);
            this.txt_studentcity.TabIndex = 5;
            // 
            // txt_studentaddress
            // 
            this.txt_studentaddress.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.txt_studentaddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_studentaddress.Location = new System.Drawing.Point(295, 207);
            this.txt_studentaddress.Name = "txt_studentaddress";
            this.txt_studentaddress.Size = new System.Drawing.Size(249, 30);
            this.txt_studentaddress.TabIndex = 6;
            // 
            // txt_studentemailid
            // 
            this.txt_studentemailid.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.txt_studentemailid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_studentemailid.Location = new System.Drawing.Point(295, 268);
            this.txt_studentemailid.Name = "txt_studentemailid";
            this.txt_studentemailid.Size = new System.Drawing.Size(249, 30);
            this.txt_studentemailid.TabIndex = 7;
            // 
            // bt_newstudent
            // 
            this.bt_newstudent.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.bt_newstudent.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_newstudent.Location = new System.Drawing.Point(82, 407);
            this.bt_newstudent.Name = "bt_newstudent";
            this.bt_newstudent.Size = new System.Drawing.Size(151, 57);
            this.bt_newstudent.TabIndex = 8;
            this.bt_newstudent.Text = "New Student";
            this.bt_newstudent.UseVisualStyleBackColor = false;
            this.bt_newstudent.Click += new System.EventHandler(this.bt_newstudent_Click);
            // 
            // bt_reset
            // 
            this.bt_reset.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.bt_reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_reset.Location = new System.Drawing.Point(410, 407);
            this.bt_reset.Name = "bt_reset";
            this.bt_reset.Size = new System.Drawing.Size(148, 57);
            this.bt_reset.TabIndex = 9;
            this.bt_reset.Text = "Reset";
            this.bt_reset.UseVisualStyleBackColor = false;
            this.bt_reset.Click += new System.EventHandler(this.bt_reset_Click);
            // 
            // bt_find
            // 
            this.bt_find.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.bt_find.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_find.Location = new System.Drawing.Point(653, 161);
            this.bt_find.Name = "bt_find";
            this.bt_find.Size = new System.Drawing.Size(136, 57);
            this.bt_find.TabIndex = 10;
            this.bt_find.Text = "Find";
            this.bt_find.UseVisualStyleBackColor = false;
            this.bt_find.Click += new System.EventHandler(this.bt_find_Click);
            // 
            // bt_search
            // 
            this.bt_search.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.bt_search.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_search.Location = new System.Drawing.Point(886, 161);
            this.bt_search.Name = "bt_search";
            this.bt_search.Size = new System.Drawing.Size(121, 57);
            this.bt_search.TabIndex = 11;
            this.bt_search.Text = "Search";
            this.bt_search.UseVisualStyleBackColor = false;
            this.bt_search.Click += new System.EventHandler(this.bt_search_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Aqua;
            this.ClientSize = new System.Drawing.Size(1119, 529);
            this.Controls.Add(this.bt_search);
            this.Controls.Add(this.bt_find);
            this.Controls.Add(this.bt_reset);
            this.Controls.Add(this.bt_newstudent);
            this.Controls.Add(this.txt_studentemailid);
            this.Controls.Add(this.txt_studentaddress);
            this.Controls.Add(this.txt_studentcity);
            this.Controls.Add(this.txt_studentname);
            this.Controls.Add(this.lbl_studentemailid);
            this.Controls.Add(this.lbl_studentaddress);
            this.Controls.Add(this.lbl_studentcity);
            this.Controls.Add(this.lbl_studentname);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_studentname;
        private System.Windows.Forms.Label lbl_studentcity;
        private System.Windows.Forms.Label lbl_studentaddress;
        private System.Windows.Forms.Label lbl_studentemailid;
        private System.Windows.Forms.TextBox txt_studentname;
        private System.Windows.Forms.TextBox txt_studentcity;
        private System.Windows.Forms.TextBox txt_studentaddress;
        private System.Windows.Forms.TextBox txt_studentemailid;
        private System.Windows.Forms.Button bt_newstudent;
        private System.Windows.Forms.Button bt_reset;
        private System.Windows.Forms.Button bt_find;
        private System.Windows.Forms.Button bt_search;
    }
}

