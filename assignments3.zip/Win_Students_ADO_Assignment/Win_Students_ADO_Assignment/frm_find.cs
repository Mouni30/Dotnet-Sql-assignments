﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Students_ADO_Assignment
{
    public partial class frm_find : Form
    {
        public frm_find()
        {
            InitializeComponent();
        }

        private void bt_find_Click(object sender, EventArgs e)
        {
            if (txt_studentid.Text == string.Empty)
            {
                MessageBox.Show("Enter ID :");
            }
            else
            {
                try
                {
                    int ID = Convert.ToInt32(txt_studentid.Text);
                    StudentDAL dal = new StudentDAL();
                    StudentModel model = dal.FindStudent(ID);
                    if (model != null)
                    {
                        txt_studentname.Text = model.StudentName;
                        txt_studentcity.Text = model.StudenCity;
                        txt_studentaddress.Text = model.StudentAddress;
                        txt_studentemailid.Text = model.StudentEmailID;
                    }
                    else
                    {
                        MessageBox.Show("Student not found");
                    }
                }
                finally
                {
                    MessageBox.Show("Finally Block");
                }

            }
        }

        private void bt_update_Click(object sender, EventArgs e)
        {
            int ID = Convert.ToInt32(txt_studentid.Text);
            string city = txt_studentcity.Text;
            string address = txt_studentaddress.Text;
            StudentDAL dal = new StudentDAL();
            bool status = dal.UpdateStudent(ID, city, address);
            if (status == true)
            {
                MessageBox.Show("Student Details Updated");
            }
            else
            {
                MessageBox.Show("Not Updated");
            }
        }

        private void bt_delete_Click(object sender, EventArgs e)
        {
            int ID = Convert.ToInt32(txt_studentid.Text);
            StudentDAL dal = new StudentDAL();
            bool status = dal.DeleteStudent(ID);
            if (status == true)
            {
                MessageBox.Show("Student Deleted");
            }
            else
            {
                MessageBox.Show("Not Deleted");
            }
        }
    }
}
